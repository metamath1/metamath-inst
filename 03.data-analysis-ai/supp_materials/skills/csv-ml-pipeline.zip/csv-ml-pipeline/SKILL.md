---
name: csv-ml-pipeline
description: >
  CSV 파일을 입력받아 자동으로 EDA 보고서, sklearn 모델 학습, Streamlit 추론 웹앱까지 한 번에 생성하는 ML 파이프라인 스킬.
  사용자가 CSV 파일을 주고 머신러닝 모델을 학습하거나 예측 앱을 만들고 싶다고 할 때 반드시 이 스킬을 사용할 것.
  "CSV로 모델 만들어줘", "이 데이터로 예측해줘", "EDA 보고서", "분류/회귀 모델", "sklearn", "머신러닝 파이프라인",
  "streamlit 앱", "추론 웹앱" 등의 표현이 나오면 이 스킬을 즉시 활성화할 것.
  사용자가 명시적으로 스킬을 언급하지 않더라도 CSV 파일 + 학습/예측/분석 요청이 함께 오면 이 스킬을 사용해야 한다.
---

# CSV ML 파이프라인 스킬 (인터랙티브 버전)

지도학습용 CSV 한 장으로 EDA → 추가 시각화(선택) → 모델 학습 → Streamlit 추론 앱까지 단계별로 진행한다.
사용자가 EDA를 검토하고 필요한 시각화를 직접 요청한 뒤, 준비가 됐을 때 ML 모델링을 트리거한다.

## 입력

- CSV 파일 1개 (필수)
- sklearn 모델명 (선택, 예: `RandomForestClassifier`, `LinearRegression`)

## 사용자에게 확인받는 시점

**1) 타겟 컬럼이 불분명할 때**
- 마지막 컬럼을 기본 타겟으로 가정
- 의미적으로 애매하거나 후보가 여럿이면 확인

**2) 모델이 지정되지 않았을 때**
- 분류/회귀 자동 판단 후 추천 모델을 제시하고 OK 받기
- 예: "타겟 'status'는 범주형이므로 분류 문제로 판단했습니다. RandomForestClassifier를 추천합니다. 진행할까요?"

**3) 결측치/이상치 발견 시**
- 결측치 비율, 이상치 범위를 보여주고 처리 전략 제안 후 승인

## 분류/회귀 자동 판단 기준

- `dtype`이 object/category이거나, int이면서 유니크 값 ≤ 10 → **분류**
- `dtype`이 float이거나, int이면서 유니크 값 > 10 → **회귀**

---

## ⚠️ 절대 규칙: 번들 스크립트를 읽거나 편집하지 말 것

이 스킬에는 완전하고 검증된 번들 스크립트가 포함되어 있다:
- `<SKILL_DIR>/scripts/run_pipeline.py` — EDA 및 ML 파이프라인 (완전한 파일, 1000줄 이상)
- `<SKILL_DIR>/scripts/add_visualization.py` — 추가 시각화 삽입
- `<SKILL_DIR>/scripts/inject_commentary.py` — 전문가 코멘트 HTML 삽입
- `<SKILL_DIR>/scripts/eda_analyst.md` — EDA 분석가 페르소나 정의

**다음 행동은 절대 금지다:**
- 스크립트 파일을 Read 도구로 열어 내용을 확인하는 것
- 스크립트 파일을 Edit/Write 도구로 수정하거나 재작성하는 것
- 스크립트가 불완전·손상돼 보여도 "복구"를 시도하는 것

스크립트 실행이 실패하면: 오류 메시지만 확인하고, 인자(argument)나 환경 설정 문제를 수정한 뒤 재시도할 것.
스크립트 내용은 항상 완전하고 올바르다고 신뢰할 것.

`<SKILL_DIR>`은 이 SKILL.md 파일이 위치한 디렉토리 경로다.

---

## ⚠️ 절대 규칙: matplotlib 텍스트는 반드시 영어만 사용

이 스킬의 실행 환경(Windows)에서는 matplotlib의 기본 폰트(DejaVu Sans)가 한글 글리프를 지원하지 않는다. 한국어 문자열을 matplotlib에 넘기면 모두 □□(박스)로 깨진다.

**이 규칙은 번들 스크립트뿐 아니라 세션 중 Claude가 직접 작성하는 모든 Python 코드에도 적용된다.**

matplotlib에 직접 전달되는 문자열은 반드시 영어로 작성한다:
- `ax.set_title()`, `plt.suptitle()` — 영어 필수
- `ax.set_xlabel()`, `ax.set_ylabel()` — 영어 필수
- `xticklabels`, `yticklabels` — 영어 필수
- `ax.legend()`, `label=` 인자 — 영어 필수
- `ax.text()`, `ax.annotate()` — 영어 필수

한국어 설명은 HTML 텍스트(`<p>`, `<div>`, `--comment` 인자 등)에만 사용한다.

---

## 인터랙티브 워크플로우 (5단계)

### PHASE 1: 패키지 설치 & EDA 실행

```bash
pip install pandas numpy scikit-learn matplotlib seaborn joblib --break-system-packages -q
```

```bash
python <SKILL_DIR>/scripts/run_pipeline.py \
  --csv <csv_경로> \
  --target <타겟_컬럼> \
  --task <classification|regression> \
  --output <출력_폴더> \
  --mode eda
```

`--mode eda`를 지정하면 EDA 보고서(`eda_report.html`)만 생성하고 ML 모델링은 건너뛴다.

EDA가 완료되면 `eda_report.html`과 함께 `stats_summary.json`이 동일 출력 폴더에 생성된다.

---

### PHASE 1-B: 전문가 코멘트 생성 및 삽입 (EDA 직후 자동 수행)

**이 단계는 EDA 직후 항상 수행한다. 사용자에게 묻지 말고 자동으로 실행한다.**

**Step 1**: `<SKILL_DIR>/scripts/eda_analyst.md` 파일을 Read 도구로 읽는다.

**Step 2**: `<출력_폴더>/stats_summary.json` 파일을 Read 도구로 읽는다.

**Step 3**: `eda_analyst.md`의 페르소나와 작성 기준에 따라, `stats_summary.json` 내용을 분석하여
아래 JSON 구조로 전문가 코멘트를 직접 생성한다:

```json
{
  "overview": "데이터셋 규모와 구조에 대한 전문가 평가 (2~4문장)",
  "missing_values": "결측치 현황과 처리 전략 (2~4문장)",
  "distributions": "수치형 컬럼 분포 특성과 변환 권고 (2~4문장)",
  "correlations": "상관관계 해석과 피처 엔지니어링 시사점 (2~4문장)",
  "target": "타겟 변수 분포와 모델링 전략 (2~4문장)"
}
```

**Step 4**: 생성한 JSON을 commentary.json 파일로 출력 폴더에 저장한다.

**Step 5**: `inject_commentary.py`를 실행해 코멘트를 EDA HTML에 삽입한다:

```bash
python <SKILL_DIR>/scripts/inject_commentary.py \
  --html <출력_폴더>/eda_report.html \
  --commentary <출력_폴더>/commentary.json
```

**Step 6**: 사용자에게 업데이트된 HTML 링크를 제공하고, 아래 세 가지 옵션을 **반드시** 함께 안내한다:

> "EDA 보고서에 전문가 코멘트를 추가했습니다. 확인해보세요.
>
> 다음 중 원하시는 것을 선택해 주세요:
> 1. **추가 시각화** — 특정 컬럼이나 관계를 더 깊이 탐색하고 싶으시면 말씀해 주세요.
> 2. **✨ WOW VISUAL INSIGHT** — 데이터에서 통계적으로 가장 흥미로운 패턴을 자동으로 탐색해 별도 리포트로 정리해드립니다. (추천)
> 3. **ML 모델링** — 바로 모델 학습을 시작할 준비가 되셨으면 말씀해 주세요."

⛔ 위 메시지 없이 바로 다음 단계로 진행하지 않는다. 반드시 사용자의 응답을 기다린다.

---

⛔ **절대 규칙: PHASE 1-B 완료 후 ML 모델링(PHASE 3)으로 자동 진행 금지**

- PHASE 1-B(전문가 코멘트 삽입)가 끝난 뒤, **사용자가 명시적으로 "모델링 시작", "ML 진행", "학습해줘" 등의 요청을 할 때까지 절대로 PHASE 3을 실행하지 않는다.**
- EDA 보고서 링크를 제공한 후에는 반드시 대기 상태로 전환하고, 사용자의 다음 지시를 기다린다.
- 사용자가 아무 말 없이도 다음 단계를 예측하여 자동으로 모델링을 실행하는 것은 엄격히 금지된다.
- 사용자가 추가 시각화(PHASE 2)를 요청하면 그것을 먼저 처리하고, 모델링은 그 이후 별도 요청이 있을 때만 진행한다.

---

### PHASE 2: 추가 시각화 (반복 가능)

#### 핵심 원칙 — 반드시 지킬 것

1. **사용자 요청 1건 = 스크립트 호출 1번 = 카드 1장**: 여러 차트가 필요해도 `--charts` JSON 배열로 한 번에 묶어서 실행한다. 절대로 같은 사용자 요청에 대해 스크립트를 여러 번 호출해서 여러 카드를 만들지 않는다.
2. **전문가 코멘트 필수**: `--comment`가 없는 호출은 금지다. 카드 전체를 아우르는 코멘트 1개를 작성해서 전달한다.
3. **`--charts` 안의 `title`은 반드시 영어**: matplotlib `ax.set_title()`에 직접 들어가므로 한국어를 쓰면 폰트 깨짐이 발생한다. 한국어 설명은 `--comment`에만 넣는다.

#### 실행 순서

**Step 1**: `<출력_폴더>/stats_summary.json`을 Read 도구로 읽어 요청된 컬럼의 통계 수치를 파악한다.

**Step 2**: 파악한 수치를 바탕으로 카드 전체에 대한 전문가 코멘트를 작성한다 (관찰 → 해석 → 활용, 2~4문장).

**Step 3**: `--charts` JSON 배열에 모든 차트를 담아 **1번만** 실행한다:

```bash
python <SKILL_DIR>/scripts/add_visualization.py \
  --html <출력_폴더>/eda_report.html \
  --csv <csv_경로> \
  --target <타겟_컬럼> \
  --charts '[{"type":"<차트종류>","cols":"<컬럼1,컬럼2,...>","title":"<English Title>"},
             {"type":"<차트종류2>","cols":"<컬럼3,컬럼4,...>","title":"<English Title 2>"}]' \
  --comment "전문가 코멘트 (2~4문장, 한국어 가능)"
```

> 카드 번호(`추가 시각화 요청 N`)는 자동으로 부여된다. `--request-num`으로 수동 지정도 가능.

**지원 차트 종류 (`type`):**

| 차트 | 설명 | `cols` 예시 |
|------|------|-------------|
| `scatter` | 두 수치형 컬럼 산점도 (타겟 색상) | `"col_x,col_y"` |
| `violin` | 수치형 컬럼 바이올린 플롯 (타겟별) | `"col"` (1개) |
| `box` | 여러 컬럼 박스플롯 비교 (타겟별) | `"col1,col2,col3"` |
| `bar` | 타겟 그룹별 평균±표준편차 바차트 | `"col"` (1개) |
| `line` | 인덱스 기준 시계열/추세 라인 | `"col1,col2"` |
| `pairplot` | 다중 컬럼 페어플롯 (타겟 색상) | `"col1,col2,col3"` (2~5개) |
| `dist` | 히스토그램 + KDE + QQ 플롯 | `"col"` (1개) |
| `heatmap` | 지정 컬럼 상관관계 히트맵 | `"col1,col2,col3"` (3개+) |
| `count` | 범주형 컬럼 빈도 바차트 + 파이 | `"col"` (범주형 1개) |

차트 삽입 후 사용자에게 업데이트된 HTML 링크를 제공하고 추가 요청 여부를 묻는다.

---

### PHASE 3: ML 모델링 실행

**모델링 실행 전 commentary.json 검토 (필수)**

1. `<출력_폴더>/commentary.json`을 Read 도구로 읽는다.
2. `target` 필드의 불균형 내용을 확인한다:
   - 불균형 비율이 **5:1 초과**이면 → `--class-weight balanced` 인자를 추가한다.
   - SMOTE 언급이 있어도 `class_weight='balanced'`를 우선 적용한다 (별도 패키지 불필요).
3. `distributions` 필드에서 극단적 왜도(|skewness| > 3) 컬럼이 언급됐다면 사용자에게 알린다.
4. 위 검토 내용을 바탕으로 모델 파라미터를 결정한 뒤 사용자에게 한 줄로 설명하고 실행한다.

사용자가 모델링 진행을 요청하면:

```bash
python <SKILL_DIR>/scripts/run_pipeline.py \
  --csv <csv_경로> \
  --target <타겟_컬럼> \
  --task <classification|regression> \
  --model <모델_클래스명> \
  --output <출력_폴더> \
  --mode model \
  [--class-weight balanced]   # 불균형 비율 5:1 초과 시에만 추가
```

`--mode model`을 지정하면 EDA를 건너뛰고 모델 학습 → 평가 보고서 → Streamlit 앱 생성만 수행한다.

생성 파일:
- `output/model.pkl`
- `output/evaluation_report.html`
- `output/app.py`
- `output/requirements.txt`

---

### PHASE 4: 완료 안내

모델링이 끝나면 반드시 다음 내용을 사용자에게 알릴 것:

```
✅ 파이프라인 완료! output/ 폴더에 다음 파일들이 생성됐습니다:
  - eda_report.html         : EDA 보고서 (추가 시각화 포함)
  - model.pkl               : 학습된 모델
  - evaluation_report.html  : 성능 평가 보고서
  - app.py                  : Streamlit 추론 웹앱
  - requirements.txt        : 의존성 목록

[Streamlit 앱 실행 방법]
  cd output/
  pip install -r requirements.txt
  streamlit run app.py

앱이 브라우저에서 자동으로 열립니다 (기본 포트: http://localhost:8501).
사이드바에 feature 값을 입력하면 실시간 예측 결과가 표시됩니다.
CSV를 업로드해서 배치 예측도 가능합니다.
```

---

---

---

## ✨ 선택 기능: WOW VISUAL INSIGHT

**실행 조건**: 다음 두 가지 중 하나에 해당하면 이 기능을 실행한다.

1. **PHASE 1-B(전문가 코멘트 삽입) 완료 직후**: 사용자에게 아래 문구로 제안하고 승인을 받는다.
   > "EDA 보고서 준비됐습니다. 추가로 **WOW VISUAL INSIGHT** 기능을 실행하면 데이터 속 통계적으로 흥미로운 패턴을 자동으로 탐색해서 별도 리포트로 정리해드릴 수 있습니다. 실행할까요?"

2. **사용자가 명시적으로 요청할 때**: "WOW", "흥미로운 패턴", "숨겨진 패턴", "인사이트 찾아줘" 등.

⛔ **사용자가 거절하거나 응답이 없으면 실행하지 않는다. 승인 없이 자동으로 실행하는 것은 금지된다.**

EDA 이후 언제든 실행 가능하며, ML 모델링과 독립적으로 동작한다.

#### Step 1: 통계 점수 계산 + 후보 PNG 생성

```bash
pip install scipy --break-system-packages -q

python <SKILL_DIR>/scripts/wow_insight.py \
  --csv <csv_경로> \
  --target <타겟_컬럼> \
  --output <출력_폴더> \
  --mode score \
  --top-n 12
```

실행 후 `<출력_폴더>/wow_candidates/` 에 PNG 파일들과 `wow_candidates_score.json`이 생성된다.

#### Step 2: Claude가 PNG를 검토하고 인사이트 선택

**이 단계는 Claude가 직접 수행한다. 사용자에게 묻지 않는다.**

1. `<SKILL_DIR>/scripts/wow_analyst.md` 파일을 Read 도구로 읽는다.
2. `<출력_폴더>/wow_candidates_score.json` 파일을 Read 도구로 읽는다.
3. PNG 파일들을 Read 도구로 순차적으로 읽어 시각적으로 검토한다.
4. `wow_analyst.md`의 선택 기준에 따라 3~6개를 선별한다.
5. 아래 형식으로 `<출력_폴더>/wow_selected.json`을 작성한다:

```json
[
  {
    "rank": 1,
    "png_path": "<candidates_score.json의 png_path 그대로>",
    "score": 0.7234,
    "insight_title": "핵심 패턴을 한 문장으로",
    "expert_comment": "관찰 → 해석 → 활용 순서의 2~4문장 코멘트"
  }
]
```

#### Step 3: WOW VISUAL INSIGHT 리포트 생성

```bash
python <SKILL_DIR>/scripts/wow_insight.py \
  --output <출력_폴더> \
  --mode build \
  --selected <출력_폴더>/wow_selected.json
```

완료 후 사용자에게 `wow_insight_report.html` 링크를 제공한다.

---

## 출력 구조

```
output/
├── eda_report.html          # EDA 보고서 (추가 시각화 포함 가능)
├── model.pkl                # 학습된 모델 (joblib)
├── evaluation_report.html   # 모델 성능 평가 보고서
├── app.py                   # Streamlit 추론 웹앱
├── requirements.txt         # 의존성 패키지 목록
├── wow_candidates/          # WOW 후보 PNG 폴더 (선택 기능 사용 시)
├── wow_candidates_score.json # 통계 점수 파일
├── wow_selected.json         # Claude가 선택한 인사이트 목록
└── wow_insight_report.html  # WOW VISUAL INSIGHT 리포트
```

## EDA 보고서에 포함되는 내용

- 데이터셋 기본 정보 (행/열 수, 컬럼, dtype)
- 기술 통계 (mean, std, min/max, percentile)
- 결측치 현황 (컬럼별 비율 + 시각화)
- 수치형 컬럼 박스플롯 매트릭스
- 수치형 컬럼 히스토그램
- 상관관계 히트맵
- 타겟 분포 (바 + 파이)
- 클래스별 피처 분포
- 데이터 불균형 경고 (분류 시)

## 평가 보고서에 포함되는 내용

**분류:** classification_report 테이블, 혼동 행렬(count + normalized), ROC/PR 커브, 특성 중요도, 전문가 해석

**회귀:** MAE/MSE/RMSE/R², 예측 vs 실제 산점도, 잔차 분포, 특성 중요도

## 에러 처리

- 패키지 설치 실패 → `--break-system-packages` 플래그 사용
- 스크립트 실패 → 오류 메시지 확인 후 재시도 (재작성 금지)
- 모델 클래스 인식 불가 → sklearn 동일 계열로 대체하고 사용자에게 알림
- `--mode model` 실행 시 기존 EDA 결과는 유지됨
