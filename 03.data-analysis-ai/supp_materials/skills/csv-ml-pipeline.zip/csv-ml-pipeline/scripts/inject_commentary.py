"""
inject_commentary.py
EDA 보고서 HTML에 전문가 코멘트 카드를 섹션별로 삽입한다.

Usage:
  python inject_commentary.py \
    --html output/eda_report.html \
    --commentary '{"overview": "...", "missing_values": "...", "distributions": "...", "correlations": "...", "target": "..."}'
"""
import argparse
import json
import re
import sys


COMMENT_CARD_STYLE = """
<style>
.analyst-comment {
  background: linear-gradient(135deg, #1a2a3a 0%, #0d1f2d 100%);
  border-left: 4px solid #4fc3f7;
  border-radius: 0 8px 8px 0;
  padding: 14px 18px;
  margin: 12px 0 0 0;
  font-size: 0.93em;
  line-height: 1.65;
  color: #cfe8f7;
}
.analyst-comment::before {
  content: "🔍 전문가 코멘트";
  display: block;
  font-size: 0.78em;
  font-weight: 700;
  color: #4fc3f7;
  letter-spacing: 0.06em;
  text-transform: uppercase;
  margin-bottom: 6px;
}
</style>
"""


SECTION_ANCHORS = [
    # (commentary_key, h2_text_pattern)
    ("overview",      r"데이터셋 개요"),
    ("missing_values", r"결측치"),
    ("basic_stats",    r"기술 통계"),
    ("distributions",  r"(분포|박스|히스토그램)"),
    ("correlations",   r"상관관계"),
    ("target",         r"타겟"),
]


def inject(html: str, commentary: dict) -> str:
    # 스타일 한 번만 삽입
    if "analyst-comment" not in html:
        html = html.replace("</head>", COMMENT_CARD_STYLE + "</head>", 1)

    for key, pattern in SECTION_ANCHORS:
        text = commentary.get(key, "").strip()
        if not text:
            continue

        card_html = f'<div class="analyst-comment">{text}</div>'

        # h2 태그를 찾아 해당 card div 끝 부분에 삽입
        # <div class="card">...<h2>...패턴...</h2> 를 찾아 </h2> 바로 뒤에 삽입
        regex = rf'(<h2>[^<]*{pattern}[^<]*</h2>)'
        replacement = rf'\1' + '\n' + card_html
        new_html, count = re.subn(regex, replacement, html, count=1, flags=re.IGNORECASE)

        if count > 0:
            html = new_html
        else:
            # h2 패턴 매칭 실패 시 </main> 바로 앞에 전체 카드로 추가
            fallback = f'''
<div class="card">
  <h2>💬 분석가 코멘트 — {key}</h2>
  {card_html}
</div>'''
            html = html.replace("</main>", fallback + "\n</main>", 1)

    return html


def main():
    parser = argparse.ArgumentParser(description="EDA 보고서에 전문가 코멘트 삽입")
    parser.add_argument("--html", required=True, help="EDA 보고서 HTML 경로")
    parser.add_argument("--commentary", required=True,
                        help='JSON 문자열 또는 JSON 파일 경로')
    args = parser.parse_args()

    # commentary 파싱 (문자열 or 파일)
    raw = args.commentary.strip()
    if raw.endswith(".json"):
        with open(raw, encoding="utf-8") as f:
            commentary = json.load(f)
    else:
        try:
            commentary = json.loads(raw)
        except json.JSONDecodeError as e:
            print(f"❌ commentary JSON 파싱 오류: {e}", file=sys.stderr)
            sys.exit(1)

    with open(args.html, encoding="utf-8") as f:
        html = f.read()

    html = inject(html, commentary)

    with open(args.html, "w", encoding="utf-8") as f:
        f.write(html)

    print(f"✅ 전문가 코멘트 삽입 완료: {args.html}")
    inserted = [k for k, _ in SECTION_ANCHORS if commentary.get(k)]
    print(f"   삽입된 섹션: {', '.join(inserted)}")


if __name__ == "__main__":
    main()
