# CSV ML 파이프라인 — Best Practices

실제 사용 사례에서 검증된 패턴과 교훈을 정리한다.

---

## Case 1: 제조업 공정 이상 감지 (다이캐스팅)

**데이터**: 다이캐스팅 공정 센서 데이터 5,161행 × 17컬럼  
**타겟**: `Machine_Status` (0=정상, 1=이상)  
**파일**: `evals/files/diecasting_sample.csv`

### 핵심 도전과 해결책

**1. 심각한 클래스 불균형 (42:1)**
- 정상 97.7% vs 이상 2.3%
- Accuracy는 항상 높게 나오므로 **절대 주요 지표로 쓰지 말 것**
- 권장: `class_weight='balanced'` + F1(이상 클래스) + AUC-PR
- Train/Test 분할 시 반드시 `stratify=y` 사용

**2. 구조적 결측치 (~7.9%)**
- 14개 센서 컬럼이 동일 시점에 동시 결측 → MAR/MNAR 가능성 높음
- 단순 행 제거 시 약 440행 손실
- 권장: `is_missing` 이진 파생 피처 생성 후 KNN/IterativeImputer 대치

**3. 극단적 분포 왜곡**
- `Cycle_Time` skewness=36.15, `Pressure_Rise_Time` skewness=47.32
- 트리 기반 모델은 상대적으로 강인하나, 이상값 자체가 공정 이상 신호일 수 있음
- 도메인 전문가 검토 후 클리핑 여부 결정 권장

### 검증된 워크플로우
```
1. stratify 분할: X_train(80%) / X_test(20%) / y_test 분리
2. X_train으로 EDA → 전문가 코멘트 확인
3. RandomForestClassifier(class_weight='balanced') 학습
4. X_test 배치 추론 → y_test 업로드로 성능 평가
5. Recall 우선 임계값 조정 검토 (FN 비용 > FP 비용)
```

### 실제 성능 결과
| 지표 | 값 |
|------|----|
| Test Accuracy | 98.4% |
| F1 (macro) | 78.5% |
| Recall 클래스 1 (이상) | 46% |
| 핵심 피처 | High_Velocity, Cylinder_Pressure, Cycle_Time |

> **교훈**: Recall 46%는 이상 감지 관점에서 낮은 수준. 실제 배포 전 임계값 조정(threshold tuning)이나 SMOTE 오버샘플링을 추가로 적용해야 함.

---

## Case 2: 여객선 생존 예측 (타이타닉)

**데이터**: `evals/files/passengers.csv` (200행)  
**타겟**: `survived` (0/1 이진 분류)

- 결측치 15행(age 컬럼) → median 대치 또는 행 제거
- 범주형 피처(sex, embarked) → 자동 레이블 인코딩 처리
- 비교적 균형 잡힌 클래스 → Accuracy + F1 모두 유효

---

## Case 3: 주택 가격 예측 (회귀)

**데이터**: `evals/files/house_prices.csv` (200행)  
**타겟**: `price` (연속형)

- `RandomForestRegressor` 지정 시 회귀 자동 감지
- 평가 지표: MAE / RMSE / R²
- 타겟 분포가 오른쪽 편향이면 log 변환 후 학습 권장

---

## 공통 원칙

1. **불균형 데이터**: `stratify=y` 분할 + `class_weight='balanced'` + F1/AUC-PR 우선
2. **결측치**: 비율 7~20%는 패턴 분석 후 KNN/IterativeImputer 권장
3. **분포 왜곡**: 트리 모델은 견고하나 선형 모델용이면 log/Box-Cox 변환 필요
4. **평가**: X_test 배치 추론 후 y_test 업로드로 실제 holdout 성능 반드시 확인
5. **도메인 해석**: EDA 전문가 코멘트는 `eda_analyst.md` 기준에 따라 생성됨
