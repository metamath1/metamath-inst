#!/usr/bin/env python3
"""
wow_insight.py — WOW VISUAL INSIGHT 엔진

통계적 점수 기반으로 흥미로운 시각화 후보를 자동 탐색하고
wow_insight_report.html 을 생성한다.

사용법:
  # PHASE A: 통계 점수 계산 + 후보 PNG 생성
  python wow_insight.py --csv data.csv --target Survived \\
    --output output/ --mode score --top-n 12

  # PHASE B: 선택된 인사이트로 HTML 리포트 생성
  python wow_insight.py --output output/ --mode build \\
    --selected output/wow_selected.json
"""

import argparse
import base64
import json
import math
import os
import sys
import warnings
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import numpy as np
import pandas as pd
import seaborn as sns
from scipy import stats

warnings.filterwarnings('ignore')

# ── matplotlib 폰트 설정 (CJK 폰트 개입 방지) ────────────────────────────────
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['font.sans-serif'] = ['DejaVu Sans', 'Arial', 'Helvetica', 'Tahoma', 'sans-serif']
plt.rcParams['axes.unicode_minus'] = False

sns.set_theme(style='whitegrid', palette='Set2')


# ───────────────────────────────────────────
# 통계 점수 계산 함수들
# ───────────────────────────────────────────

def cohens_d(group1, group2):
    """두 그룹 간 Cohen's d 효과 크기"""
    n1, n2 = len(group1), len(group2)
    if n1 < 2 or n2 < 2:
        return 0.0
    var1 = group1.var(ddof=1) if n1 > 1 else 0.0
    var2 = group2.var(ddof=1) if n2 > 1 else 0.0
    pooled_std = math.sqrt(((n1 - 1) * var1 + (n2 - 1) * var2) / (n1 + n2 - 2))
    if pooled_std < 1e-9:
        return 0.0
    return abs(float(group1.mean()) - float(group2.mean())) / pooled_std


def bimodality_coefficient(series):
    """
    Bimodality Coefficient (BC) — 이중 봉우리 분포 감지
    BC > 0.555 → 이중 봉우리 가능성 높음
    """
    data = series.dropna()
    n = len(data)
    if n < 4:
        return 0.0
    s = float(data.skew())
    k = float(data.kurt())  # excess kurtosis
    denom = k + 3.0 * (n - 1) ** 2 / max((n - 2) * (n - 3), 1)
    if abs(denom) < 1e-9:
        return 0.0
    bc = (s ** 2 + 1.0) / denom
    return float(np.clip(bc, 0.0, 1.0))


def variance_ratio(df, num_col, cat_col):
    """
    Eta-squared 근사: 범주형으로 그룹화했을 때 수치 컬럼 분산 설명 비율
    """
    groups = [g[num_col].dropna() for _, g in df.groupby(cat_col)]
    groups = [g for g in groups if len(g) >= 2]
    if len(groups) < 2:
        return 0.0
    try:
        f_stat, _ = stats.f_oneway(*groups)
        if not np.isfinite(f_stat) or f_stat < 0:
            return 0.0
        k = len(groups)
        n = sum(len(g) for g in groups)
        eta2 = (f_stat * (k - 1)) / (f_stat * (k - 1) + max(n - k, 1))
        return float(np.clip(eta2, 0.0, 1.0))
    except Exception:
        return 0.0


def max_cohens_d_normalized(df, num_col, cat_col):
    """그룹 쌍 중 가장 큰 Cohen's d를 [0, 1]로 정규화해서 반환"""
    groups = {name: grp[num_col].dropna()
              for name, grp in df.groupby(cat_col)
              if len(grp[num_col].dropna()) >= 2}
    keys = list(groups.keys())
    max_d = 0.0
    for i in range(len(keys)):
        for j in range(i + 1, len(keys)):
            d = cohens_d(groups[keys[i]], groups[keys[j]])
            max_d = max(max_d, d)
    # d=0 → 0.0, d=2 → 1.0 (clamp)
    return float(np.clip(max_d / 2.0, 0.0, 1.0))


def composite_score(eta2, d_norm, bc, weights=(0.45, 0.35, 0.20)):
    return weights[0] * eta2 + weights[1] * d_norm + weights[2] * bc


# ───────────────────────────────────────────
# 후보 PNG 생성 함수들
# ───────────────────────────────────────────

def save_violin(df, num_col, cat_col, png_path, target=None):
    fig, ax = plt.subplots(figsize=(8, 5))
    hue = target if (target and target != cat_col and target in df.columns
                     and df[target].nunique() <= 10) else None
    try:
        sns.violinplot(data=df, x=cat_col, y=num_col, hue=hue,
                       ax=ax, inner='quartile', cut=0, density_norm='width')
    except TypeError:
        # 구버전 seaborn 호환
        try:
            sns.violinplot(data=df, x=cat_col, y=num_col, hue=hue,
                           ax=ax, inner='quartile', cut=0, scale='width')
        except Exception:
            sns.boxplot(data=df, x=cat_col, y=num_col, hue=hue, ax=ax)
    ax.set_title(f'{num_col}  ×  {cat_col}', fontsize=13, fontweight='bold', pad=12)
    ax.tick_params(axis='x', rotation=30)
    plt.tight_layout()
    fig.savefig(png_path, dpi=100, bbox_inches='tight')
    plt.close(fig)


def save_dist(df, num_col, png_path):
    data = df[num_col].dropna()
    fig = plt.figure(figsize=(10, 4))
    gs = gridspec.GridSpec(1, 2, width_ratios=[2, 1], figure=fig)

    ax1 = fig.add_subplot(gs[0])
    ax1.hist(data, bins=30, density=True, alpha=0.6, color='steelblue', edgecolor='white')
    try:
        kde = stats.gaussian_kde(data)
        x = np.linspace(data.min(), data.max(), 200)
        ax1.plot(x, kde(x), color='darkorange', lw=2, label='KDE')
        ax1.legend(fontsize=9)
    except Exception:
        pass
    ax1.set_title(f'{num_col} — Distribution', fontsize=12, fontweight='bold')
    ax1.set_xlabel(num_col)
    ax1.set_ylabel('Density')

    ax2 = fig.add_subplot(gs[1])
    try:
        (osm, osr), (slope, intercept, r) = stats.probplot(data, dist='norm')
        ax2.plot(osm, osr, 'o', alpha=0.5, markersize=4, color='steelblue')
        ax2.plot(osm, slope * np.array(osm) + intercept, 'r-', lw=1.5)
        ax2.set_title(f'QQ Plot  (R={r:.3f})', fontsize=11, fontweight='bold')
        ax2.set_xlabel('Theoretical Quantiles')
        ax2.set_ylabel('Sample Quantiles')
    except Exception:
        ax2.text(0.5, 0.5, 'QQ Plot\nFailed', ha='center', va='center', transform=ax2.transAxes)

    plt.tight_layout()
    fig.savefig(png_path, dpi=100, bbox_inches='tight')
    plt.close(fig)


def save_scatter_3way(df, num1, num2, cat_col, png_path):
    fig, ax = plt.subplots(figsize=(8, 5))
    groups = sorted(df[cat_col].dropna().unique())
    palette = sns.color_palette('Set2', len(groups))
    for i, grp in enumerate(groups):
        sub = df[df[cat_col] == grp]
        ax.scatter(sub[num1], sub[num2], label=str(grp),
                   alpha=0.6, s=30, color=palette[i])
    ax.set_xlabel(num1, fontsize=10)
    ax.set_ylabel(num2, fontsize=10)
    ax.set_title(f'{num1}  vs  {num2}  (color: {cat_col})', fontsize=12, fontweight='bold', pad=12)
    ax.legend(title=cat_col, bbox_to_anchor=(1.02, 1), loc='upper left', fontsize=8)
    plt.tight_layout()
    fig.savefig(png_path, dpi=100, bbox_inches='tight')
    plt.close(fig)


# ───────────────────────────────────────────
# PHASE A: 점수 계산 및 PNG 생성
# ───────────────────────────────────────────

def phase_score(csv_path, target, output_dir, top_n):
    df = pd.read_csv(csv_path)
    out = Path(output_dir)
    cand_dir = out / 'wow_candidates'
    cand_dir.mkdir(parents=True, exist_ok=True)

    # 컬럼 분류
    num_cols = df.select_dtypes(include='number').columns.tolist()
    cat_cols = df.select_dtypes(include=['object', 'category']).columns.tolist()

    # 타겟 처리
    if target in df.columns:
        # 타겟이 수치형이지만 유니크 ≤ 15이면 범주형으로도 취급
        if df[target].nunique() <= 15 and target not in cat_cols:
            cat_cols.append(target)
        if target in num_cols:
            num_cols.remove(target)

    # 유효한 범주형: 유니크 2~15개
    cat_cols = [c for c in cat_cols
                if c in df.columns and 2 <= df[c].nunique() <= 15]
    num_cols = [c for c in num_cols if c in df.columns]

    print(f"[WOW] 데이터: {df.shape[0]}행 × {df.shape[1]}열")
    print(f"[WOW] 수치형 컬럼 {len(num_cols)}개, 범주형 컬럼 {len(cat_cols)}개")
    print(f"[WOW] 타겟: {target}")

    candidates = []

    # ─── 1) Numeric × Categorical violin ───────────────────────────
    print("[WOW] 수치형 × 범주형 조합 점수 계산 중...")
    for num in num_cols:
        for cat in cat_cols:
            eta2 = variance_ratio(df, num, cat)
            d_norm = max_cohens_d_normalized(df, num, cat)
            bc = bimodality_coefficient(df[num])
            score = composite_score(eta2, d_norm, bc)
            if score < 0.04:
                continue
            candidates.append({
                'type': 'violin',
                'feature': num,
                'group_by': cat,
                'score': round(score, 4),
                'stats': {
                    'eta_squared': round(eta2, 4),
                    'cohens_d_norm': round(d_norm, 4),
                    'bimodality': round(bc, 4)
                }
            })

    # ─── 2) 이중 봉우리 분포 ────────────────────────────────────────
    for num in num_cols:
        bc = bimodality_coefficient(df[num])
        if bc > 0.555:
            candidates.append({
                'type': 'dist',
                'feature': num,
                'group_by': None,
                'score': round(bc * 0.65, 4),
                'stats': {'bimodality': round(bc, 4)}
            })

    # ─── 3) Scatter (수치 × 수치, 범주 색상) ──────────────────────
    if len(num_cols) >= 2 and cat_cols:
        if target in df.columns and pd.api.types.is_numeric_dtype(df[target]):
            corr_vals = df[num_cols + [target]].corr()[target].drop(target).abs()
        else:
            corr_vals = pd.Series(dtype=float)

        top_nums = corr_vals.nlargest(min(5, len(corr_vals))).index.tolist() \
            if not corr_vals.empty else num_cols[:5]

        for i, n1 in enumerate(top_nums):
            for n2 in top_nums[i + 1:]:
                for cat in cat_cols[:3]:
                    eta2_1 = variance_ratio(df, n1, cat)
                    eta2_2 = variance_ratio(df, n2, cat)
                    score = (eta2_1 + eta2_2) / 2.0
                    if score < 0.06:
                        continue
                    candidates.append({
                        'type': 'scatter',
                        'feature': f'{n1},{n2}',
                        'group_by': cat,
                        'score': round(score, 4),
                        'stats': {
                            'eta2_feat1': round(eta2_1, 4),
                            'eta2_feat2': round(eta2_2, 4)
                        }
                    })

    # 점수 내림차순 정렬 + 중복 제거
    candidates.sort(key=lambda x: x['score'], reverse=True)
    seen = set()
    unique_cands = []
    for c in candidates:
        key = (c['type'], c['feature'], c['group_by'])
        if key not in seen:
            seen.add(key)
            unique_cands.append(c)
    candidates = unique_cands[:top_n]

    if not candidates:
        print("[WOW] 유효한 후보가 없습니다. 데이터 구조를 확인하세요.")
        sys.exit(0)

    # PNG 생성
    print(f"\n[WOW] 상위 {len(candidates)}개 후보 PNG 생성 중...")
    for i, cand in enumerate(candidates, 1):
        safe_feat = cand['feature'].replace(',', '_')
        safe_grp = cand['group_by'] or 'dist'
        fname = f"{i:02d}_{safe_feat}_by_{safe_grp}.png"
        png_path = str(cand_dir / fname)
        cand['rank'] = i
        cand['png_path'] = png_path

        try:
            if cand['type'] == 'violin':
                save_violin(df, cand['feature'], cand['group_by'], png_path, target=target)
            elif cand['type'] == 'dist':
                save_dist(df, cand['feature'], png_path)
            elif cand['type'] == 'scatter':
                n1, n2 = cand['feature'].split(',', 1)
                save_scatter_3way(df, n1.strip(), n2.strip(), cand['group_by'], png_path)
            print(f"  [{i:2d}/{len(candidates)}] {fname}  (score={cand['score']})")
        except Exception as e:
            print(f"  [{i:2d}] 생성 실패: {e}")
            cand['png_path'] = None

    # wow_candidates_score.json 저장
    score_path = out / 'wow_candidates_score.json'
    with open(score_path, 'w', encoding='utf-8') as f:
        json.dump(candidates, f, ensure_ascii=False, indent=2)

    print(f"\n[WOW] 점수 파일 저장: {score_path}")
    print(f"[WOW] PNG 폴더: {cand_dir}/")
    print("\n" + "─" * 60)
    print("다음 단계: Claude가 PNG를 검토하고 wow_selected.json을 작성합니다.")
    print("─" * 60)
    return str(score_path)


# ───────────────────────────────────────────
# PHASE B: 선택된 인사이트로 HTML 리포트 생성
# ───────────────────────────────────────────

def img_to_b64(png_path):
    with open(png_path, 'rb') as f:
        return base64.b64encode(f.read()).decode()


def build_insight_card(rank, title, b64, comment, score=None):
    score_badge = ''
    if score is not None:
        score_badge = (
            f'<span style="background:#4fc3f7;color:#0d1f2d;padding:2px 10px;'
            f'border-radius:12px;font-size:.78em;font-weight:700;margin-left:10px;">'
            f'score {score:.3f}</span>'
        )
    return f"""
<div class="wow-card" style="
  background: linear-gradient(135deg, #0f1e2e 0%, #1a2d3d 100%);
  border: 1px solid #2a4a6a;
  border-radius: 12px;
  padding: 28px 32px;
  margin: 28px 0;
  box-shadow: 0 4px 24px rgba(0,0,0,0.35);
">
  <div style="display:flex;align-items:center;margin-bottom:18px;flex-wrap:wrap;gap:8px;">
    <span style="
      background: linear-gradient(135deg, #4fc3f7, #0288d1);
      color: #fff;
      width: 36px; height: 36px;
      border-radius: 50%;
      display: inline-flex; align-items: center; justify-content: center;
      font-weight: 800; font-size: 1.1em;
      flex-shrink: 0;
    ">#{rank}</span>
    <h2 style="margin:0;color:#e8f4fd;font-size:1.18em;font-weight:700;flex:1;">{title}</h2>
    {score_badge}
  </div>
  <img src="data:image/png;base64,{b64}"
       style="width:100%;border-radius:8px;margin-bottom:16px;border:1px solid #2a4a6a;">
  <div style="
    background: linear-gradient(135deg, #1a2a3a 0%, #0d1f2d 100%);
    border-left: 4px solid #4fc3f7;
    border-radius: 0 8px 8px 0;
    padding: 14px 18px;
    font-size: .93em;
    line-height: 1.65;
    color: #cfe8f7;
  ">
    <span style="display:block;font-size:.78em;font-weight:700;color:#4fc3f7;
      letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px;">
      💡 WOW 인사이트 코멘트</span>
    {comment}
  </div>
</div>"""


def phase_build(selected_path, output_dir):
    out = Path(output_dir)
    with open(selected_path, 'r', encoding='utf-8') as f:
        selected = json.load(f)

    cards_html = ''
    built = 0
    for item in selected:
        png_path = item.get('png_path', '')
        if not png_path or not Path(png_path).exists():
            print(f"[WOW] PNG 없음, 건너뜀: {png_path}")
            continue
        try:
            b64 = img_to_b64(png_path)
        except Exception as e:
            print(f"[WOW] PNG 읽기 실패: {png_path} — {e}")
            continue
        cards_html += build_insight_card(
            rank=item.get('rank', built + 1),
            title=item.get('insight_title', '인사이트'),
            b64=b64,
            comment=item.get('expert_comment', ''),
            score=item.get('score')
        )
        built += 1

    if built == 0:
        print("[WOW] 오류: 삽입할 인사이트 카드가 없습니다. wow_selected.json을 확인하세요.")
        sys.exit(1)

    html = f"""<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>WOW VISUAL INSIGHT 리포트</title>
<style>
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{
    font-family: 'Segoe UI', 'Noto Sans KR', sans-serif;
    background: #060f18;
    color: #c8dce8;
    min-height: 100vh;
    padding: 40px 20px;
  }}
  .container {{ max-width: 920px; margin: 0 auto; }}
  .hero {{
    text-align: center;
    padding: 48px 32px 40px;
    background: linear-gradient(135deg, #0d1f2d 0%, #1a3a52 100%);
    border-radius: 16px;
    border: 1px solid #2a5a7a;
    margin-bottom: 40px;
    box-shadow: 0 8px 40px rgba(0,0,0,0.5);
  }}
  .hero h1 {{
    font-size: 2em;
    font-weight: 900;
    color: #4fc3f7;
    letter-spacing: .04em;
    margin-bottom: 12px;
  }}
  .hero p {{
    color: #8ab4c8;
    font-size: 1em;
    line-height: 1.6;
    margin-top: 10px;
  }}
  .badge {{
    display: inline-block;
    background: linear-gradient(90deg, #0288d1, #4fc3f7);
    color: #fff;
    padding: 4px 18px;
    border-radius: 20px;
    font-size: .82em;
    font-weight: 700;
    margin-bottom: 18px;
    letter-spacing: .06em;
    text-transform: uppercase;
  }}
  .footer {{
    text-align: center;
    color: #4a6a80;
    font-size: .82em;
    margin-top: 60px;
    padding-top: 24px;
    border-top: 1px solid #1a3a52;
  }}
</style>
</head>
<body>
<div class="container">
  <div class="hero">
    <div class="badge">✨ WOW VISUAL INSIGHT</div>
    <h1>데이터 속 숨겨진 패턴 발견</h1>
    <p>통계적 점수와 시각적 검토를 통해 선별된<br>
    가장 흥미롭고 실용적인 인사이트 <strong style="color:#4fc3f7;">{built}개</strong></p>
  </div>
  {cards_html}
  <div class="footer">
    Generated by csv-ml-pipeline · WOW VISUAL INSIGHT Engine
  </div>
</div>
</body>
</html>"""

    report_path = out / 'wow_insight_report.html'
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write(html)
    print(f"[WOW] 리포트 생성 완료: {report_path}")
    return str(report_path)


# ───────────────────────────────────────────
# main
# ───────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description='WOW VISUAL INSIGHT 엔진',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__
    )
    parser.add_argument('--csv', help='CSV 파일 경로')
    parser.add_argument('--target', help='타겟 컬럼명')
    parser.add_argument('--output', required=True, help='출력 폴더')
    parser.add_argument('--mode', choices=['score', 'build'], required=True,
                        help='score: 후보 생성 | build: HTML 리포트 생성')
    parser.add_argument('--top-n', type=int, default=12,
                        help='상위 후보 수 (기본값: 12)')
    parser.add_argument('--selected',
                        help='선택된 인사이트 JSON 경로 (--mode build 시 필수)')
    args = parser.parse_args()

    if args.mode == 'score':
        if not args.csv or not args.target:
            print("오류: --mode score 는 --csv 와 --target 이 필요합니다.", file=sys.stderr)
            sys.exit(1)
        phase_score(args.csv, args.target, args.output, args.top_n)

    elif args.mode == 'build':
        if not args.selected:
            print("오류: --mode build 는 --selected 가 필요합니다.", file=sys.stderr)
            sys.exit(1)
        phase_build(args.selected, args.output)


if __name__ == '__main__':
    main()
