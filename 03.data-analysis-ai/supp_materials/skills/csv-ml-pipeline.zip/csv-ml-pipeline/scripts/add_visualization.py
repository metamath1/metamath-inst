#!/usr/bin/env python3
"""
add_visualization.py
기존 eda_report.html에 사용자가 요청한 차트를 추가한다.

【신규 멀티차트 모드 — 권장】
  사용자의 추가 시각화 요청 1건 = 카드 1장 = add_visualization.py 호출 1번

  python add_visualization.py \\
    --html output/eda_report.html \\
    --csv data.csv \\
    --target Machine_Status \\
    --charts '[{"type":"violin","cols":"Velocity_1","title":"Velocity_1 by Machine Status"},
               {"type":"box","cols":"Velocity_1,Cylinder_Pressure,Rapid_Rise_Time","title":"Box Plots by Machine Status"}]' \\
    --comment "전문가 코멘트 (2~4문장)"

  ※ charts 배열 안의 title은 matplotlib ax.set_title()에 들어가므로 반드시 영어로 작성한다.
  ※ comment는 HTML에 들어가므로 한국어 가능.
  ※ --request-num을 생략하면 HTML 내 기존 카드 수를 세어 자동 번호를 부여한다.

【단일차트 모드 — 하위호환】
  python add_visualization.py \\
    --html output/eda_report.html \\
    --csv data.csv \\
    --target Machine_Status \\
    --chart violin \\
    --cols Velocity_1 \\
    --title "Velocity_1 by Machine Status" \\
    --comment "전문가 코멘트"

지원 차트 타입:
  scatter  violin  box  bar  line  pairplot  dist  heatmap  count
"""
import argparse
import base64
import json
import os
import sys
import warnings
from io import BytesIO

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

warnings.filterwarnings('ignore')

# ── matplotlib 폰트 설정 (CJK 폰트 개입 방지) ────────────────────────────────
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['font.sans-serif'] = ['DejaVu Sans', 'Arial', 'Helvetica', 'Tahoma', 'sans-serif']
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['figure.facecolor'] = 'white'
plt.rcParams['axes.facecolor'] = '#f8f9fa'
plt.rcParams['axes.grid'] = True
plt.rcParams['grid.alpha'] = 0.3


# ── 유틸 ─────────────────────────────────────────────────────────────────────
def fig_to_b64(fig):
    buf = BytesIO()
    fig.savefig(buf, format='png', dpi=130, bbox_inches='tight')
    plt.close(fig)
    buf.seek(0)
    return base64.b64encode(buf.read()).decode()


def count_request_cards(html_path):
    """기존 HTML에서 '추가 시각화 요청' 카드 수를 세어 자동 번호 부여에 사용"""
    try:
        with open(html_path, 'r', encoding='utf-8') as f:
            content = f.read()
        return content.count('추가 시각화 요청')
    except Exception:
        return 0


def make_comment_block(comment):
    """전문가 코멘트 블록 — class 없이 inline style만 사용 (CSS ::before 중복 방지)"""
    return f'''
<div style="
  background:linear-gradient(135deg,#1a2a3a 0%,#0d1f2d 100%);
  border-left:4px solid #4fc3f7;border-radius:0 8px 8px 0;
  padding:14px 18px;margin:24px 0 0 0;font-size:.93em;
  line-height:1.65;color:#cfe8f7;">
  <span style="display:block;font-size:.78em;font-weight:700;color:#4fc3f7;
    letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px;">
    🔍 전문가 코멘트</span>
  {comment}
</div>'''


def make_chart_block(title, b64, caption=''):
    """카드 안에 들어가는 개별 차트 블록 (카드 래퍼 없음)"""
    title_html = (
        f'<h3 style="font-size:1rem;color:#1a3a5c;margin:0 0 12px 0;'
        f'font-weight:600;padding-left:8px;border-left:3px solid #e94560;">'
        f'{title}</h3>'
    ) if title else ''
    cap_html = (
        f'<p style="text-align:center;font-size:.78rem;color:#888;margin-top:6px">'
        f'{caption}</p>'
    ) if caption else ''
    return f"""
<div style="margin-bottom:28px;padding-bottom:24px;border-bottom:1px solid #eee;">
  {title_html}
  <img src="data:image/png;base64,{b64}"
       style="max-width:100%;border-radius:8px;display:block;margin:0 auto">
  {cap_html}
</div>"""


def make_multi_card(request_num, chart_blocks, comment=''):
    """여러 차트를 담는 번호형 카드 (추가 시각화 요청 N)"""
    charts_html = '\n'.join(chart_blocks)
    comment_html = make_comment_block(comment) if comment else ''
    return f"""
<div class="card" style="background:#fff;border-radius:14px;padding:28px 32px;
     margin-bottom:28px;box-shadow:0 2px 12px rgba(0,0,0,.07)">
  <h2 style="font-size:1.2rem;color:#0f3460;margin-bottom:24px;
             border-left:4px solid #e94560;padding-left:12px;font-weight:600">
    ➕ 추가 시각화 요청 {request_num}
  </h2>
  {charts_html}
  {comment_html}
</div>"""


def inject_into_html(html_path, section_html):
    """</main> 직전에 섹션 삽입"""
    with open(html_path, 'r', encoding='utf-8') as f:
        content = f.read()
    if '</main>' in content:
        content = content.replace('</main>', section_html + '\n</main>', 1)
    else:
        content += section_html
    with open(html_path, 'w', encoding='utf-8') as f:
        f.write(content)
    print(f"✅ 차트 추가 완료: {html_path}")


# ── 차트 생성 함수들 ──────────────────────────────────────────────────────────
def chart_scatter(df, cols, target, title):
    if len(cols) < 2:
        sys.exit("scatter: --cols에 컬럼 2개 필요 (예: --cols col_x,col_y)")
    cx, cy = cols[0], cols[1]
    classes = df[target].dropna().unique()
    palette = ['#0f3460', '#e94560', '#16213e', '#533483', '#ff9800']

    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    for i, cls in enumerate(sorted(classes)):
        sub = df[df[target] == cls]
        axes[0].scatter(sub[cx], sub[cy], alpha=0.45, s=15,
                        label=f'Class {cls}', color=palette[i % len(palette)])
    axes[0].set_xlabel(cx); axes[0].set_ylabel(cy)
    axes[0].set_title(f'{cx} vs {cy}', fontweight='bold')
    axes[0].legend()

    try:
        for i, cls in enumerate(sorted(classes)):
            sub = df[df[target] == cls][[cx, cy]].dropna()
            if len(sub) > 20:
                sns.kdeplot(data=sub, x=cx, y=cy, ax=axes[1],
                            color=palette[i % len(palette)], fill=True,
                            alpha=0.3, label=f'Class {cls}')
        axes[1].set_title(f'{cx} vs {cy} (KDE Density)', fontweight='bold')
        axes[1].legend()
    except Exception:
        axes[1].set_visible(False)

    plt.suptitle(title or f'Scatter: {cx} vs {cy}', fontsize=13, y=1.01)
    plt.tight_layout()
    return fig_to_b64(fig), f'Scatter plot of {cx} vs {cy}, colored by {target}'


def chart_violin(df, cols, target, title):
    col = cols[0]
    palette = sns.color_palette('Set2', df[target].nunique())
    df_plot = df[[col, target]].dropna()
    df_plot[target] = df_plot[target].astype(str)

    fig, ax = plt.subplots(figsize=(10, 5))
    try:
        sns.violinplot(data=df_plot, x=target, y=col, ax=ax,
                       palette=palette, inner='box', linewidth=1.2)
    except TypeError:
        sns.violinplot(data=df_plot, x=target, y=col, ax=ax,
                       palette=palette, inner='box')
    ax.set_title(title or f'{col} by {target}', fontweight='bold', fontsize=13)
    ax.set_xlabel(target); ax.set_ylabel(col)
    plt.tight_layout()
    return fig_to_b64(fig), f'Violin plot of {col} grouped by {target}'


def chart_box(df, cols, target, title):
    n = len(cols)
    ncols = min(n, 4)
    nrows = (n + ncols - 1) // ncols
    fig, axes = plt.subplots(nrows, ncols, figsize=(4.5*ncols, 4*nrows))
    axes = np.array(axes).flatten()
    palette = sns.color_palette('Set2', df[target].nunique())

    for i, col in enumerate(cols):
        df_plot = df[[col, target]].dropna()
        df_plot[target] = df_plot[target].astype(str)
        sns.boxplot(data=df_plot, x=target, y=col, ax=axes[i], palette=palette)
        axes[i].set_title(col, fontweight='bold', fontsize=9)
        axes[i].set_xlabel(target); axes[i].set_ylabel(col)
    for j in range(i+1, len(axes)):
        axes[j].set_visible(False)

    plt.suptitle(title or f'Box Plots by {target}', fontsize=13, y=1.01)
    plt.tight_layout()
    return fig_to_b64(fig), f'Box plots of selected columns grouped by {target}'


def chart_bar(df, cols, target, title):
    col = cols[0]
    df_plot = df[[col, target]].dropna()
    df_plot[target] = df_plot[target].astype(str)
    grouped = df_plot.groupby(target)[col].agg(['mean', 'std', 'count'])

    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    palette = sns.color_palette('Set2', len(grouped))

    bars = axes[0].bar(grouped.index, grouped['mean'],
                       color=palette, edgecolor='white', linewidth=1.5,
                       yerr=grouped['std'], capsize=5, alpha=0.85)
    axes[0].set_xlabel(target); axes[0].set_ylabel(f'Mean of {col}')
    axes[0].set_title(f'Mean {col} by {target} (+-std)', fontweight='bold')
    for bar, (idx, row) in zip(bars, grouped.iterrows()):
        axes[0].text(bar.get_x() + bar.get_width()/2,
                     bar.get_height() + grouped['std'].max()*0.05,
                     f'{row["mean"]:.3g}', ha='center', fontsize=9)

    axes[1].bar(grouped.index, grouped['count'], color=palette,
                edgecolor='white', linewidth=1.5, alpha=0.85)
    axes[1].set_xlabel(target); axes[1].set_ylabel('Sample Count')
    axes[1].set_title(f'Sample Count by {target}', fontweight='bold')

    plt.suptitle(title or f'{col} by {target}', fontsize=13, y=1.01)
    plt.tight_layout()
    return fig_to_b64(fig), f'Mean and sample count of {col} grouped by {target}'


def chart_line(df, cols, target, title):
    fig, ax = plt.subplots(figsize=(14, 5))
    palette = plt.cm.tab10.colors
    for i, col in enumerate(cols):
        ax.plot(df.index, df[col], alpha=0.7, linewidth=1,
                label=col, color=palette[i % 10])
    ax.set_xlabel('Index'); ax.set_ylabel('Value')
    ax.set_title(title or f'Line Chart: {", ".join(cols)}', fontweight='bold')
    ax.legend(loc='upper right', fontsize=8)
    plt.tight_layout()
    return fig_to_b64(fig), f'Time series / line chart for: {", ".join(cols)}'


def chart_pairplot(df, cols, target, title):
    cols = cols[:6]
    df_plot = df[cols + [target]].dropna()
    df_plot[target] = df_plot[target].astype(str)
    n = len(cols)

    fig, axes = plt.subplots(n, n, figsize=(3*n, 3*n))
    palette = sns.color_palette('Set2', df_plot[target].nunique())
    classes = sorted(df_plot[target].unique())

    for i, col_y in enumerate(cols):
        for j, col_x in enumerate(cols):
            ax = axes[i][j]
            if i == j:
                for k, cls in enumerate(classes):
                    sub = df_plot[df_plot[target] == cls][col_x].dropna()
                    ax.hist(sub, bins=20, alpha=0.5, color=palette[k], density=True)
                ax.set_title(col_x, fontsize=7, fontweight='bold')
            else:
                for k, cls in enumerate(classes):
                    sub = df_plot[df_plot[target] == cls]
                    ax.scatter(sub[col_x], sub[col_y], alpha=0.3, s=8,
                               color=palette[k], label=f'Class {cls}')
            if j == 0:
                ax.set_ylabel(col_y, fontsize=7)
            if i == n-1:
                ax.set_xlabel(col_x, fontsize=7)
            ax.tick_params(labelsize=6)

    from matplotlib.patches import Patch
    legend_elems = [Patch(facecolor=palette[k], label=f'Class {cls}')
                    for k, cls in enumerate(classes)]
    fig.legend(handles=legend_elems, loc='upper right', fontsize=8)
    plt.suptitle(title or f'Pair Plot ({", ".join(cols)})', fontsize=12, y=1.01)
    plt.tight_layout()
    return fig_to_b64(fig), f'Pair plot of {len(cols)} features colored by {target}'


def chart_dist(df, cols, target, title):
    col = cols[0]
    data = df[col].dropna()
    fig, axes = plt.subplots(1, 3, figsize=(16, 4))

    axes[0].hist(data, bins=40, color='#0f3460', alpha=0.7,
                 edgecolor='white', density=True, label='Histogram')
    try:
        from scipy.stats import gaussian_kde
        kde = gaussian_kde(data)
        x = np.linspace(data.min(), data.max(), 300)
        axes[0].plot(x, kde(x), color='#e94560', lw=2, label='KDE')
    except ImportError:
        pass
    axes[0].axvline(data.mean(), color='orange', lw=1.5, linestyle='--',
                    label=f'Mean={data.mean():.4g}')
    axes[0].axvline(data.median(), color='green', lw=1.5, linestyle=':',
                    label=f'Median={data.median():.4g}')
    axes[0].set_title(f'{col} Distribution', fontweight='bold')
    axes[0].legend(fontsize=7)

    axes[1].boxplot(data, vert=True, patch_artist=True,
                    boxprops=dict(facecolor='#0f3460', alpha=0.6),
                    medianprops=dict(color='#e94560', lw=2))
    sample = data.sample(min(300, len(data)))
    axes[1].scatter(np.ones(len(sample)) + np.random.uniform(-0.1, 0.1, len(sample)),
                    sample, alpha=0.3, s=10, color='#e94560')
    axes[1].set_title(f'{col} Box + Swarm', fontweight='bold')
    axes[1].set_xticks([])

    try:
        from scipy import stats as sp_stats
        qq = sp_stats.probplot(data, dist='norm')
        axes[2].scatter(qq[0][0], qq[0][1], s=10, alpha=0.5, color='#0f3460')
        x_line = np.array([qq[0][0].min(), qq[0][0].max()])
        axes[2].plot(x_line, qq[1][0]*x_line + qq[1][1], 'r-', lw=2)
        axes[2].set_xlabel('Theoretical Quantiles')
        axes[2].set_ylabel('Sample Quantiles')
        axes[2].set_title(f'{col} Q-Q Plot (Normal)', fontweight='bold')
    except ImportError:
        sorted_data = np.sort(data)
        p = np.arange(1, len(sorted_data)+1) / len(sorted_data)
        axes[2].plot(sorted_data, p, color='#0f3460', lw=1.5)
        axes[2].set_xlabel(col); axes[2].set_ylabel('Cumulative Probability')
        axes[2].set_title(f'{col} CDF', fontweight='bold')

    plt.suptitle(title or f'Detailed Distribution: {col}', fontsize=13, y=1.01)
    plt.tight_layout()
    stats_str = (f'mean={data.mean():.4g} | std={data.std():.4g} | '
                 f'skew={data.skew():.3f} | kurt={data.kurtosis():.3f}')
    return fig_to_b64(fig), stats_str


def chart_heatmap(df, cols, target, title):
    df_sub = df[cols].select_dtypes(include=np.number)
    corr = df_sub.corr()
    n = len(corr)
    fig, ax = plt.subplots(figsize=(max(7, n*0.8), max(6, n*0.7)))
    sns.heatmap(corr, annot=True, fmt='.3f', cmap='RdBu_r', center=0,
                ax=ax, linewidths=0.5, annot_kws={'size': 9},
                cbar_kws={'shrink': 0.8})
    ax.set_title(title or f'Correlation Heatmap ({len(cols)} features)',
                 fontweight='bold')
    plt.xticks(rotation=45, ha='right', fontsize=8)
    plt.yticks(fontsize=8)
    plt.tight_layout()
    return fig_to_b64(fig), 'Subset correlation heatmap'


def chart_count(df, cols, target, title):
    col = cols[0]
    vc = df[col].value_counts()
    n = min(30, len(vc))
    fig, axes = plt.subplots(1, 2, figsize=(14, max(4, n*0.3)))

    palette = sns.color_palette('Set2', n)
    axes[0].barh(vc.index[:n][::-1], vc.values[:n][::-1], color=palette[::-1])
    axes[0].set_title(f'{col} Value Counts (Top {n})', fontweight='bold')
    axes[0].set_xlabel('Count')
    for i, v in enumerate(vc.values[:n][::-1]):
        axes[0].text(v + vc.values.max()*0.01, i, str(v), va='center', fontsize=8)

    axes[1].pie(vc.values[:n], labels=vc.index[:n].astype(str),
                autopct='%1.1f%%', colors=palette,
                wedgeprops={'edgecolor': 'white', 'linewidth': 1.5})
    axes[1].set_title(f'Category Distribution: {col} (%)', fontweight='bold')

    plt.suptitle(title or f'Category Distribution: {col}', fontsize=13, y=1.01)
    plt.tight_layout()
    return fig_to_b64(fig), f'Value counts for categorical column: {col}'


# ── 차트 타입 라우팅 ──────────────────────────────────────────────────────────
CHART_FUNCS = {
    'scatter':  chart_scatter,
    'violin':   chart_violin,
    'box':      chart_box,
    'bar':      chart_bar,
    'line':     chart_line,
    'pairplot': chart_pairplot,
    'dist':     chart_dist,
    'heatmap':  chart_heatmap,
    'count':    chart_count,
}


def generate_chart_block(df, chart_type, cols_str, target, title=''):
    """단일 차트를 생성해 chart_block HTML 반환"""
    cols = [c.strip() for c in cols_str.split(',') if c.strip()]
    bad = [c for c in cols if c not in df.columns]
    if bad:
        print(f"⚠️  없는 컬럼 무시됨: {bad}", file=sys.stderr)
        cols = [c for c in cols if c in df.columns]
    if not cols:
        return None

    if chart_type not in CHART_FUNCS:
        print(f"⚠️  지원하지 않는 차트 타입: {chart_type}", file=sys.stderr)
        return None

    print(f"  📊 {chart_type} / cols: {cols}")
    func = CHART_FUNCS[chart_type]
    b64, caption = func(df, cols, target, title)
    display_title = title or f'{chart_type.capitalize()}: {", ".join(cols)}'
    return make_chart_block(display_title, b64, caption)


def main():
    parser = argparse.ArgumentParser(
        description='EDA 보고서에 시각화 차트 추가',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__
    )
    parser.add_argument('--html',    required=True, help='기존 eda_report.html 경로')
    parser.add_argument('--csv',     required=True, help='원본 CSV 파일 경로')
    parser.add_argument('--target',  required=True, help='타겟 컬럼명')
    parser.add_argument('--comment', default='',    help='전문가 코멘트 (카드 전체에 1개)')
    parser.add_argument('--request-num', type=int, default=0,
                        help='카드 번호 (0=자동, HTML 내 기존 카드 수 +1)')

    # ── 멀티차트 모드 ──────────────────────────────────────────────────────────
    parser.add_argument('--charts', default='',
                        help='JSON 배열: [{"type":"violin","cols":"col1","title":"English Title"}, ...]')

    # ── 단일차트 모드 (하위호환) ──────────────────────────────────────────────
    parser.add_argument('--chart',  default='', choices=list(CHART_FUNCS.keys()) + [''],
                        help='차트 타입 (단일 모드)')
    parser.add_argument('--cols',   default='', help='컬럼 목록 (단일 모드)')
    parser.add_argument('--title',  default='', help='차트 제목 — 반드시 영어로 작성')

    args = parser.parse_args()

    # CSV 로딩
    df = pd.read_csv(args.csv)

    # 카드 번호 결정
    req_num = args.request_num or (count_request_cards(args.html) + 1)

    chart_blocks = []

    if args.charts:
        # ── 멀티차트 모드 ──────────────────────────────────────────────────────
        try:
            specs = json.loads(args.charts)
        except json.JSONDecodeError as e:
            sys.exit(f"❌ --charts JSON 파싱 오류: {e}")

        for spec in specs:
            ct    = spec.get('type', '')
            cols_ = spec.get('cols', '')
            ttl   = spec.get('title', '')  # 반드시 영어
            block = generate_chart_block(df, ct, cols_, args.target, ttl)
            if block:
                chart_blocks.append(block)

    elif args.chart and args.cols:
        # ── 단일차트 모드 (하위호환) ───────────────────────────────────────────
        block = generate_chart_block(df, args.chart, args.cols, args.target, args.title)
        if block:
            chart_blocks.append(block)
    else:
        sys.exit("❌ --charts 또는 (--chart + --cols) 중 하나를 지정하세요.")

    if not chart_blocks:
        sys.exit("❌ 생성된 차트가 없습니다. 컬럼명과 차트 타입을 확인하세요.")

    section_html = make_multi_card(req_num, chart_blocks, comment=args.comment)
    inject_into_html(args.html, section_html)
    print(f"   → 추가 시각화 요청 {req_num}: {len(chart_blocks)}개 차트 삽입 완료")


if __name__ == '__main__':
    main()
