#!/usr/bin/env python3
"""
CSV ML Pipeline - Automated machine learning pipeline for CSV files
"""
import argparse
import base64
import json
import os
import pickle
import warnings
from io import BytesIO

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, classification_report, confusion_matrix,
    mean_squared_error, r2_score, roc_curve, auc,
    precision_score, recall_score, f1_score
)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

warnings.filterwarnings('ignore')

# ── matplotlib 폰트 설정 (CJK 폰트 개입 방지) ────────────────────────────────
# Windows 시스템에서 맑은 고딕 등 CJK 폰트가 기본 폰트로 설정되는 문제를 방지한다.
# matplotlib 기본 폰트(DejaVu Sans)를 명시적으로 고정한다.
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['font.sans-serif'] = ['DejaVu Sans', 'Arial', 'Helvetica', 'Tahoma', 'sans-serif']
plt.rcParams['axes.unicode_minus'] = False   # 마이너스 기호 깨짐 방지
plt.rcParams['figure.facecolor'] = 'white'
plt.rcParams['axes.facecolor'] = '#f8f9fa'
plt.rcParams['axes.grid'] = True
plt.rcParams['grid.alpha'] = 0.3


# ── 공통 유틸 ─────────────────────────────────────────────────────────────────
def fig_to_b64(fig):
    buf = BytesIO()
    fig.savefig(buf, format='png', dpi=120, bbox_inches='tight')
    plt.close(fig)
    buf.seek(0)
    return base64.b64encode(buf.read()).decode()


def img_tag(b64, caption=''):
    cap = f'<p class="caption">{caption}</p>' if caption else ''
    return f'<div class="chart-wrap"><img src="data:image/png;base64,{b64}" class="chart">{cap}</div>'


BASE_CSS = """
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
     background:#f0f2f5;color:#1a1a2e;line-height:1.6}
header{background:linear-gradient(135deg,#1a1a2e 0%,#16213e 50%,#0f3460 100%);
       color:#fff;padding:40px 56px}
header h1{font-size:2rem;font-weight:700;letter-spacing:-.5px}
header .meta{margin-top:10px;opacity:.8;font-size:.95rem;display:flex;gap:24px;flex-wrap:wrap}
header .badge{background:rgba(255,255,255,.15);border-radius:20px;padding:3px 12px;font-size:.82rem}
main{max-width:1280px;margin:0 auto;padding:36px 24px}
.card{background:#fff;border-radius:14px;padding:28px 32px;margin-bottom:28px;
      box-shadow:0 2px 12px rgba(0,0,0,.07)}
h2{font-size:1.2rem;color:#0f3460;margin-bottom:18px;
   border-left:4px solid #e94560;padding-left:12px;font-weight:600}
h3{font-size:1rem;color:#444;margin:20px 0 10px;font-weight:600}
.table{width:100%;border-collapse:collapse;font-size:.875rem}
.table th{background:#f0f4f8;padding:10px 14px;text-align:left;
          border-bottom:2px solid #dde3ea;color:#333;font-weight:600}
.table td{padding:9px 14px;border-bottom:1px solid #f0f2f5}
.table tr:hover td{background:#fafbff}
.chart{max-width:100%;border-radius:8px;display:block;margin:0 auto}
.chart-wrap{margin:14px 0}
.caption{text-align:center;font-size:.8rem;color:#888;margin-top:6px}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:20px}
.grid3{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}
.metric-card{background:linear-gradient(135deg,#f8faff,#eef2ff);
             border:1px solid #dde8f5;border-radius:10px;padding:20px;text-align:center}
.metric-card .val{font-size:2rem;font-weight:700;color:#0f3460}
.metric-card .lbl{font-size:.82rem;color:#666;margin-top:4px}
.info{background:#e8f5e9;border-left:4px solid #4caf50;
      padding:12px 16px;border-radius:0 8px 8px 0;margin:10px 0;font-size:.9rem}
.warn{background:#fff3e0;border-left:4px solid #ff9800;
      padding:12px 16px;border-radius:0 8px 8px 0;margin:10px 0;font-size:.9rem}
.insight{background:linear-gradient(135deg,#e8eaf6,#f3e5f5);
         border-left:4px solid #7c4dff;padding:16px 20px;border-radius:0 12px 12px 0;
         margin:14px 0;font-size:.92rem;line-height:1.7}
.insight h4{color:#4a148c;margin-bottom:8px;font-size:.95rem}
.insight ul{padding-left:18px}
.insight li{margin-bottom:5px}
@media(max-width:768px){.grid2,.grid3{grid-template-columns:1fr}}
</style>"""

HTML_HEADER = '<!DOCTYPE html><html lang="ko"><head><meta charset="UTF-8">' \
              '<meta name="viewport" content="width=device-width,initial-scale=1">' \
              '<title>{title}</title>' + BASE_CSS + '</head><body>'


# ── 데이터 로딩 & 전처리 ──────────────────────────────────────────────────────
def load_csv(csv_path):
    return pd.read_csv(csv_path)


def preprocess_data(df, target_col):
    df_processed = df.copy()
    missing_count = df_processed.isna().sum().sum()
    print(f"Missing values found: {missing_count}")
    if missing_count > 0:
        df_processed = df_processed.dropna()
        print(f"After removing missing values: {df_processed.shape}")

    X = df_processed.drop(columns=[target_col])
    y = df_processed[target_col]

    categorical_cols = X.select_dtypes(include=['object']).columns
    label_encoders = {}
    for col in categorical_cols:
        le = LabelEncoder()
        X[col] = le.fit_transform(X[col].astype(str))
        label_encoders[col] = le

    return X, y, label_encoders


# ── EDA 보고서 ────────────────────────────────────────────────────────────────
def generate_eda_report(df, target_col, output_dir):
    num_cols = df.select_dtypes(include=np.number).columns.tolist()
    cat_cols = df.select_dtypes(include='object').columns.tolist()
    feat_cols = [c for c in df.columns if c != target_col]
    num_feats = [c for c in num_cols if c != target_col]

    sections = []

    # ── 1. 데이터셋 개요 ──────────────────────────────────────────────────────
    overview_rows = [
        ('행 수', f'{len(df):,}'), ('열 수', str(len(df.columns))),
        ('타겟 컬럼', f'<b>{target_col}</b>'),
        ('수치형 컬럼', str(len(num_cols))), ('범주형 컬럼', str(len(cat_cols))),
        ('총 결측치', f'{df.isnull().sum().sum():,}'),
        ('중복 행', f'{df.duplicated().sum():,}'),
    ]
    rows_html = ''.join(f'<tr><th>{k}</th><td>{v}</td></tr>' for k, v in overview_rows)
    sections.append(f'''
    <div class="card">
      <h2>📋 데이터셋 개요</h2>
      <table class="table"><tbody>{rows_html}</tbody></table>
    </div>''')

    # ── 2. 결측치 시각화 ──────────────────────────────────────────────────────
    missing = df.isnull().sum()
    missing_pct = (missing / len(df) * 100).round(2)
    missing_df = pd.DataFrame({'결측 수': missing, '비율(%)': missing_pct})
    missing_df = missing_df[missing_df['결측 수'] > 0].sort_values('비율(%)', ascending=False)

    if len(missing_df) == 0:
        missing_html = '<div class="info">✅ 결측치 없음</div>'
        chart_missing = ''
    else:
        missing_html = missing_df.to_html(classes='table', border=0)
        fig, axes = plt.subplots(1, 2, figsize=(14, max(4, len(missing_df)*0.45)))
        # 바차트
        colors = ['#e94560' if p > 20 else '#ff9800' if p > 5 else '#4caf50'
                  for p in missing_df['비율(%)']]
        axes[0].barh(missing_df.index[::-1], missing_df['비율(%)'][::-1], color=colors[::-1])
        axes[0].set_xlabel('Missing Rate (%)')
        axes[0].set_title('Missing Rate by Column')
        for i, (idx, row) in enumerate(missing_df.iloc[::-1].iterrows()):
            axes[0].text(row['비율(%)']+0.3, i, f"{row['비율(%)']:.1f}%", va='center', fontsize=8)
        # 히트맵 스타일 (샘플 200행)
        sample = df[missing_df.index].head(200).isnull()
        if len(sample.columns) > 0:
            axes[1].imshow(sample.T.values, aspect='auto', cmap='RdYlGn_r', vmin=0, vmax=1)
            axes[1].set_yticks(range(len(sample.columns)))
            axes[1].set_yticklabels(sample.columns, fontsize=8)
            axes[1].set_xlabel('Sample Index (first 200 rows)')
            axes[1].set_title('Missing Pattern (red=missing)')
        else:
            axes[1].axis('off')
        plt.tight_layout()
        chart_missing = img_tag(fig_to_b64(fig), '결측치 분포 및 패턴')

    sections.append(f'''
    <div class="card">
      <h2>🔍 결측치 현황</h2>
      {missing_html}
      {chart_missing}
    </div>''')

    # ── 3. 기술 통계 + 시각화 ────────────────────────────────────────────────
    desc = df[num_cols].describe().round(4)
    desc_html = desc.to_html(classes='table', border=0)

    # 박스플롯 행렬 (수치형 feature)
    if num_feats:
        n = min(len(num_feats), 16)
        cols_per_row = 4
        rows_ = (n + cols_per_row - 1) // cols_per_row
        fig, axes = plt.subplots(rows_, cols_per_row, figsize=(16, rows_*3))
        axes = np.array(axes).flatten()
        palette = plt.cm.tab10.colors
        for i, col in enumerate(num_feats[:n]):
            bp = axes[i].boxplot(df[col].dropna(), vert=True, patch_artist=True,
                                 boxprops=dict(facecolor=palette[i % 10], alpha=0.7),
                                 medianprops=dict(color='#e94560', linewidth=2),
                                 whiskerprops=dict(linewidth=1.2),
                                 flierprops=dict(marker='o', markersize=3, alpha=0.4))
            axes[i].set_title(col, fontsize=9, fontweight='bold')
            axes[i].tick_params(axis='x', labelbottom=False)
            q1, q3 = df[col].quantile(0.25), df[col].quantile(0.75)
            iqr = q3 - q1
            outliers = ((df[col] < q1 - 1.5*iqr) | (df[col] > q3 + 1.5*iqr)).sum()
            if outliers > 0:
                axes[i].set_xlabel(f'{outliers} outliers', fontsize=7, color='#e94560')
        for j in range(i+1, len(axes)):
            axes[j].set_visible(False)
        plt.suptitle('Numeric Feature Distributions (Box Plot)', fontsize=13, y=1.01)
        plt.tight_layout()
        box_chart = img_tag(fig_to_b64(fig), 'IQR 기준 이상치 포함 분포')
    else:
        box_chart = ''

    sections.append(f'''
    <div class="card">
      <h2>📊 기술 통계</h2>
      {desc_html}
      {box_chart}
    </div>''')

    # ── 4. 분포 히스토그램 ───────────────────────────────────────────────────
    if num_feats:
        n = min(len(num_feats), 16)
        cols_per_row = 4
        rows_ = (n + cols_per_row - 1) // cols_per_row
        fig, axes = plt.subplots(rows_, cols_per_row, figsize=(16, rows_*3))
        axes = np.array(axes).flatten()
        palette = plt.cm.Set2.colors
        for i, col in enumerate(num_feats[:n]):
            data = df[col].dropna()
            axes[i].hist(data, bins=30, color=palette[i % len(palette)],
                         edgecolor='white', alpha=0.85)
            axes[i].axvline(data.mean(), color='#e94560', linewidth=1.5,
                            linestyle='--', label=f'Mean {data.mean():.3g}')
            axes[i].axvline(data.median(), color='#0f3460', linewidth=1.5,
                            linestyle=':', label=f'Median {data.median():.3g}')
            axes[i].set_title(col, fontsize=9, fontweight='bold')
            axes[i].legend(fontsize=6, loc='upper right')
        for j in range(i+1, len(axes)):
            axes[j].set_visible(False)
        plt.suptitle('Numeric Feature Histograms', fontsize=13, y=1.01)
        plt.tight_layout()
        hist_chart = img_tag(fig_to_b64(fig), '빨간 점선=평균, 파란 점선=중앙값')

        sections.append(f'''
        <div class="card">
          <h2>📉 수치형 분포 히스토그램</h2>
          {hist_chart}
        </div>''')

    # ── 5. 상관관계 히트맵 ───────────────────────────────────────────────────
    if len(num_cols) > 1:
        corr = df[num_cols].corr()
        n_c = len(corr)
        fig, ax = plt.subplots(figsize=(max(9, n_c*0.75), max(7, n_c*0.65)))
        mask = np.triu(np.ones_like(corr, dtype=bool), k=1)  # 상삼각 마스크 제거 (전체 표시)
        mask[:] = False  # 전체 표시
        sns.heatmap(corr, annot=n_c <= 15, fmt='.2f', cmap='RdBu_r',
                    center=0, ax=ax, linewidths=0.5, annot_kws={'size': 8},
                    cbar_kws={'shrink': 0.8})
        ax.set_title('Feature Correlation Heatmap', fontsize=13)
        plt.xticks(rotation=45, ha='right', fontsize=8)
        plt.yticks(fontsize=8)
        plt.tight_layout()
        # 타겟과 높은 상관관계 top5
        if target_col in corr.columns:
            top_corr = corr[target_col].drop(target_col).abs().nlargest(5)
            top_html = '<h3>타겟과 상관관계 Top 5</h3><table class="table"><tr><th>Feature</th><th>|상관계수|</th></tr>'
            for feat, val in top_corr.items():
                dir_ = '양의' if corr[target_col][feat] > 0 else '음의'
                top_html += f'<tr><td>{feat}</td><td>{val:.4f} ({dir_} 상관)</td></tr>'
            top_html += '</table>'
        else:
            top_html = ''

        sections.append(f'''
        <div class="card">
          <h2>🔗 상관관계 분석</h2>
          {img_tag(fig_to_b64(fig), '1에 가까울수록 강한 양의 상관, -1에 가까울수록 강한 음의 상관')}
          {top_html}
        </div>''')

    # ── 6. 타겟 변수 분석 ────────────────────────────────────────────────────
    target_series = df[target_col].dropna()
    is_clf = target_series.nunique() <= 10 and (
        target_series.dtype == object or target_series.nunique() <= 10)

    if is_clf:
        vc = target_series.value_counts()
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))
        colors = ['#0f3460', '#e94560', '#16213e', '#533483']
        ax1.bar([str(v) for v in vc.index], vc.values,
                color=colors[:len(vc)], edgecolor='white', linewidth=1.5)
        ax1.set_title(f'Class Distribution: {target_col}', fontweight='bold')
        ax1.set_xlabel('Class'); ax1.set_ylabel('Count')
        for bar, val in zip(ax1.patches, vc.values):
            ax1.text(bar.get_x() + bar.get_width()/2, bar.get_height()+10,
                     f'{val:,}\n({val/len(target_series)*100:.1f}%)',
                     ha='center', fontsize=9)
        ax2.pie(vc.values, labels=[str(v) for v in vc.index],
                autopct='%1.1f%%', colors=colors[:len(vc)],
                wedgeprops={'edgecolor': 'white', 'linewidth': 2})
        ax2.set_title('Class Ratio', fontweight='bold')
        plt.tight_layout()
        target_chart = img_tag(fig_to_b64(fig), '클래스 불균형 여부 확인')

        # 클래스별 feature 분포 (상위 4개 feature)
        if num_feats:
            top_f = num_feats[:min(4, len(num_feats))]
            fig, axes = plt.subplots(1, len(top_f), figsize=(4*len(top_f), 4))
            if len(top_f) == 1:
                axes = [axes]
            for ax, feat in zip(axes, top_f):
                for cls, color in zip(vc.index, colors):
                    subset = df[df[target_col] == cls][feat].dropna()
                    ax.hist(subset, bins=20, alpha=0.6, label=f'Class {cls}',
                            color=color, edgecolor='white')
                ax.set_title(f'{feat}', fontsize=9, fontweight='bold')
                ax.legend(fontsize=7)
            plt.suptitle('Feature Distribution by Class', fontsize=12)
            plt.tight_layout()
            class_feat_chart = img_tag(fig_to_b64(fig), '클래스 간 Feature 분포 차이')
        else:
            class_feat_chart = ''

        imbalance_ratio = vc.max() / vc.min() if vc.min() > 0 else float('inf')
        imbalance_note = ''
        if imbalance_ratio > 3:
            imbalance_note = f'''<div class="warn">⚠️ 클래스 불균형 감지: 다수 클래스가 소수 클래스의 {imbalance_ratio:.1f}배
            — Accuracy보다 F1/Recall/Precision을 중점적으로 봐야 합니다.</div>'''

        target_section = f'{target_chart}{imbalance_note}{class_feat_chart}'
    else:
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))
        ax1.hist(target_series, bins=40, color='#0f3460', alpha=0.8, edgecolor='white')
        ax1.axvline(target_series.mean(), color='#e94560', linewidth=2,
                    linestyle='--', label=f'Mean {target_series.mean():.4g}')
        ax1.axvline(target_series.median(), color='#ff9800', linewidth=2,
                    linestyle=':', label=f'Median {target_series.median():.4g}')
        ax1.set_title(f'{target_col} Distribution'); ax1.legend()
        ax2.boxplot(target_series, vert=False, patch_artist=True,
                    boxprops=dict(facecolor='#0f3460', alpha=0.7),
                    medianprops=dict(color='#e94560', linewidth=2))
        ax2.set_title(f'{target_col} Boxplot')
        plt.tight_layout()
        target_section = img_tag(fig_to_b64(fig))

    sections.append(f'''
    <div class="card">
      <h2>🎯 타겟 변수 분석: {target_col}</h2>
      {target_section}
    </div>''')

    # ── stats_summary.json 생성 (EDA Analyst 코멘트용) ───────────────────────
    try:
        from scipy import stats as scipy_stats
        def safe_skew(s): return float(scipy_stats.skew(s.dropna()))
        def safe_kurt(s): return float(scipy_stats.kurtosis(s.dropna()))
    except ImportError:
        def safe_skew(s): return float(s.dropna().skew()) if hasattr(s, 'skew') else 0.0
        def safe_kurt(s): return float(s.dropna().kurt()) if hasattr(s, 'kurt') else 0.0

    missing_full = df.isnull().sum()
    missing_pct_full = (missing_full / len(df) * 100).round(2)

    numeric_stats_summary = {}
    for c in num_feats:
        col_data = df[c].dropna()
        q1, q3 = col_data.quantile(0.25), col_data.quantile(0.75)
        iqr = q3 - q1
        outliers = int(((col_data < q1 - 1.5*iqr) | (col_data > q3 + 1.5*iqr)).sum())
        numeric_stats_summary[c] = {
            'mean': round(float(col_data.mean()), 4),
            'std':  round(float(col_data.std()), 4),
            'min':  round(float(col_data.min()), 4),
            'max':  round(float(col_data.max()), 4),
            'skewness': round(safe_skew(df[c]), 4),
            'kurtosis': round(safe_kurt(df[c]), 4),
            'outlier_count': outliers,
            'outlier_pct': round(outliers / max(len(col_data), 1) * 100, 2),
            'missing_pct': float(missing_pct_full.get(c, 0)),
        }

    # 상관관계
    corr_with_target, high_corr_pairs = {}, []
    if target_col in df.select_dtypes(include=np.number).columns:
        for c in num_feats:
            try: corr_with_target[c] = round(float(df[c].corr(df[target_col])), 4)
            except: pass
    num_df = df[num_feats].select_dtypes(include=np.number)
    if len(num_df.columns) > 1:
        cm = num_df.corr().abs()
        for i in range(len(cm.columns)):
            for j in range(i+1, len(cm.columns)):
                v = cm.iloc[i, j]
                if v > 0.75:
                    high_corr_pairs.append({'col1': cm.columns[i], 'col2': cm.columns[j], 'r': round(float(v), 4)})

    # 타겟 분포
    target_dist = {}
    if df[target_col].dtype == object or df[target_col].nunique() <= 10:
        vc = df[target_col].value_counts()
        target_dist = {'type': 'classification',
                       'class_counts': {str(k): int(v) for k, v in vc.items()},
                       'imbalance_ratio': round(float(vc.max() / max(vc.min(), 1)), 2)}
    else:
        t = df[target_col].dropna()
        target_dist = {'type': 'regression',
                       'mean': round(float(t.mean()), 4), 'std': round(float(t.std()), 4),
                       'skewness': round(safe_skew(t), 4)}

    stats_summary = {
        'dataset': {
            'rows': len(df), 'cols': len(df.columns),
            'target_col': target_col,
            'numeric_features': len(num_feats),
            'categorical_features': len(cat_cols),
            'total_missing': int(df.isnull().sum().sum()),
            'duplicates': int(df.duplicated().sum()),
        },
        'missing': {c: float(missing_pct_full[c]) for c in df.columns if missing_pct_full[c] > 0},
        'numeric_stats': numeric_stats_summary,
        'correlations': {
            'with_target': dict(sorted(corr_with_target.items(), key=lambda x: abs(x[1]), reverse=True)[:10]),
            'high_corr_pairs': high_corr_pairs[:10],
        },
        'target_distribution': target_dist,
    }

    stats_path = os.path.join(output_dir, 'stats_summary.json')
    with open(stats_path, 'w', encoding='utf-8') as f:
        json.dump(stats_summary, f, ensure_ascii=False, indent=2)
    print(f"  - Stats summary: {stats_path}")

    # ── HTML 조립 ─────────────────────────────────────────────────────────────
    html = HTML_HEADER.replace('{title}', 'EDA Report')
    html += f'''
    <header>
      <h1>📊 탐색적 데이터 분석 보고서</h1>
      <div class="meta">
        <span class="badge">파일: {os.path.basename(output_dir)}</span>
        <span class="badge">타겟: {target_col}</span>
        <span class="badge">행: {len(df):,} | 열: {len(df.columns)}</span>
      </div>
    </header>
    <main>{"".join(sections)}</main></body></html>'''

    path = os.path.join(output_dir, 'eda_report.html')
    with open(path, 'w', encoding='utf-8') as f:
        f.write(html)
    print(f"  - EDA report: {path}")
    return path


# ── 모델 학습 / 평가 ─────────────────────────────────────────────────────────
def train_model(X_train, y_train, model_type='RandomForestRegressor', task='regression', class_weight=None):
    if task == 'regression':
        model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
    else:
        kwargs = dict(n_estimators=100, random_state=42, n_jobs=-1)
        if class_weight:
            kwargs['class_weight'] = class_weight
            print(f"  ⚖️  class_weight='{class_weight}' 적용 (불균형 보정)")
        model = RandomForestClassifier(**kwargs)
    model.fit(X_train, y_train)
    return model


def evaluate_model(model, X_test, y_test, task='regression'):
    y_pred = model.predict(X_test)
    metrics = {}
    if task == 'regression':
        mse = mean_squared_error(y_test, y_pred)
        metrics['MSE'] = float(mse)
        metrics['RMSE'] = float(np.sqrt(mse))
        metrics['MAE'] = float(np.mean(np.abs(y_test - y_pred)))
        metrics['R²'] = float(r2_score(y_test, y_pred))
    else:
        metrics['Accuracy'] = float(accuracy_score(y_test, y_pred))
        metrics['Precision (macro)'] = float(precision_score(y_test, y_pred, average='macro', zero_division=0))
        metrics['Recall (macro)'] = float(recall_score(y_test, y_pred, average='macro', zero_division=0))
        metrics['F1 (macro)'] = float(f1_score(y_test, y_pred, average='macro', zero_division=0))
        metrics['F1 (weighted)'] = float(f1_score(y_test, y_pred, average='weighted', zero_division=0))
    return metrics, y_pred


def save_model(model, output_dir):
    path = os.path.join(output_dir, 'model.pkl')
    with open(path, 'wb') as f:
        pickle.dump(model, f)
    return path


def save_metadata(model, X, metrics, output_dir, target_col, task, model_type):
    meta = {
        'model_type': model_type, 'task_type': task,
        'target_column': target_col,
        'feature_count': len(X.columns), 'features': list(X.columns),
        'metrics': metrics,
        'n_samples_train': len(X) - int(0.2*len(X)),
        'n_samples_test': int(0.2*len(X))
    }
    path = os.path.join(output_dir, 'metadata.json')
    with open(path, 'w') as f:
        json.dump(meta, f, indent=2)
    return path


# ── 전문가 해석 생성 ─────────────────────────────────────────────────────────
def build_expert_interpretation(metrics, y_test, y_pred, task, target_col):
    """타겟 컬럼명과 성능 지표를 바탕으로 도메인 맞춤 해석 생성"""

    target_lower = target_col.lower()
    is_binary = len(np.unique(y_test)) == 2

    if task == 'regression':
        r2 = metrics.get('R²', 0)
        rmse = metrics.get('RMSE', 0)
        mae = metrics.get('MAE', 0)
        mean_target = float(np.mean(y_test))
        pct_err = rmse / mean_target * 100 if mean_target != 0 else 0

        if r2 >= 0.9:
            quality = '매우 우수 (R² ≥ 0.9)'
            quality_desc = '예측값이 실제값의 변동을 90% 이상 설명합니다.'
        elif r2 >= 0.7:
            quality = '양호 (0.7 ≤ R² < 0.9)'
            quality_desc = '예측 방향성은 신뢰할 수 있으나, 극단값에서 오차가 발생할 수 있습니다.'
        else:
            quality = '개선 필요 (R² < 0.7)'
            quality_desc = '설명력이 낮습니다. Feature Engineering 또는 더 복잡한 모델을 검토해 보세요.'

        return f'''
        <div class="insight">
          <h4>🧠 데이터 사이언스 전문가 해석</h4>
          <p><strong>모델 품질:</strong> {quality} — {quality_desc}</p>
          <br>
          <ul>
            <li><strong>RMSE {rmse:,.4g}</strong> — 예측값이 실제값과 평균적으로 ±{rmse:,.4g} 오차를 가집니다.
                타겟 평균({mean_target:,.4g}) 대비 약 {pct_err:.1f}% 수준의 오차입니다.</li>
            <li><strong>MAE {mae:,.4g}</strong> — 이상치에 덜 민감한 지표입니다.
                RMSE와 MAE의 차이({rmse - mae:,.4g})가 클수록 큰 오차가 간헐적으로 발생한다는 신호입니다.</li>
            <li><strong>R² {r2:.4f}</strong> — 모델이 타겟 분산의 {r2*100:.1f}%를 설명합니다.
                나머지 {(1-r2)*100:.1f}%는 모델이 포착하지 못한 패턴(노이즈, 미수집 Feature 등)입니다.</li>
          </ul>
          <br>
          <p><strong>실무 활용 관점:</strong> RMSE와 MAE 중 어느 것을 최적화 기준으로 삼을지는
          운영 요구사항에 따라 다릅니다. 큰 오차가 치명적인 경우(예: 생산 불량) → RMSE 최소화,
          안정적인 평균 오차가 중요한 경우(예: 납기 예측) → MAE 최소화를 권장합니다.</p>
        </div>'''

    else:  # classification
        acc = metrics.get('Accuracy', 0)
        prec = metrics.get('Precision (macro)', 0)
        rec = metrics.get('Recall (macro)', 0)
        f1 = metrics.get('F1 (macro)', 0)

        # 도메인 컨텍스트 추론
        is_quality_domain = any(k in target_lower for k in
            ['status', 'defect', 'fault', 'fail', 'quality', 'ok', 'ng', 'good', 'bad',
             'error', 'anomaly', 'alarm', 'reject'])
        is_medical = any(k in target_lower for k in
            ['disease', 'cancer', 'diagnos', 'patient', 'positive', 'sick'])
        is_fraud = any(k in target_lower for k in ['fraud', 'cheat', 'abuse'])

        if is_quality_domain:
            context = '제조·품질 관리 도메인'
            prec_meaning = ('Precision은 "불량이라고 예측한 것 중 실제 불량 비율"입니다. '
                           'Precision이 낮으면 정상 제품을 불필요하게 폐기하는 비용이 증가합니다.')
            rec_meaning = ('Recall은 "실제 불량 중 모델이 잡아낸 비율"입니다. '
                          'Recall이 낮으면 불량품이 출하되어 고객 클레임·리콜로 이어질 수 있습니다.')
            tradeoff = ('제조 현장에서는 일반적으로 <strong>Recall을 우선시</strong>합니다. '
                       '불량 미검출(False Negative)의 비용이 과잉 검출(False Positive)보다 훨씬 크기 때문입니다. '
                       '따라서 Recall을 높이는 방향(임계값 낮추기, SMOTE 등)을 고려하세요.')
        elif is_medical:
            context = '의료·진단 도메인'
            prec_meaning = 'Precision은 "양성 예측 중 실제 양성 비율"로, 불필요한 치료/검사 비율과 직결됩니다.'
            rec_meaning = 'Recall(Sensitivity)은 "실제 환자 중 놓치지 않은 비율"로, 환자 안전과 직결됩니다.'
            tradeoff = '의료 진단에서는 <strong>Recall(민감도)을 최우선</strong>으로 합니다. 환자를 놓치는 것이 과잉 진단보다 위험합니다.'
        elif is_fraud:
            context = '이상거래·사기 탐지 도메인'
            prec_meaning = 'Precision은 "사기로 의심한 것 중 실제 사기 비율"입니다. 낮으면 정상 사용자 불편이 증가합니다.'
            rec_meaning = 'Recall은 "실제 사기 중 탐지한 비율"입니다. 낮으면 실제 사기를 놓치게 됩니다.'
            tradeoff = 'Precision과 Recall의 균형을 맞추되, 사기 피해 규모에 따라 Recall을 높이는 방향을 검토하세요.'
        else:
            context = '일반 분류 도메인'
            prec_meaning = 'Precision은 모델이 양성이라 예측한 것 중 실제 양성 비율입니다.'
            rec_meaning = 'Recall은 실제 양성 중 모델이 올바르게 예측한 비율입니다.'
            tradeoff = ('Precision과 Recall은 Trade-off 관계입니다. '
                       '어느 쪽을 우선할지는 FP와 FN 중 어떤 실수가 더 비싼지를 기준으로 결정하세요.')

        pr_gap = abs(prec - rec)
        if prec > rec + 0.1:
            pr_note = f'현재 Precision({prec:.3f}) > Recall({rec:.3f}): 모델이 보수적으로 예측합니다. 실제 양성을 일부 놓치고 있을 수 있습니다.'
        elif rec > prec + 0.1:
            pr_note = f'현재 Recall({rec:.3f}) > Precision({prec:.3f}): 모델이 적극적으로 양성을 예측합니다. 불필요한 경보가 증가할 수 있습니다.'
        else:
            pr_note = f'Precision({prec:.3f})과 Recall({rec:.3f})이 균형 잡혀 있습니다.'

        if f1 >= 0.9:
            f1_eval = '매우 우수'
        elif f1 >= 0.75:
            f1_eval = '양호'
        elif f1 >= 0.6:
            f1_eval = '보통 (개선 여지 있음)'
        else:
            f1_eval = '낮음 (모델 개선 필요)'

        return f'''
        <div class="insight">
          <h4>🧠 데이터 사이언스 전문가 해석 ({context})</h4>
          <p><strong>종합 평가:</strong> F1 Score {f1:.4f} — {f1_eval}</p>
          <br>
          <ul>
            <li><strong>Precision:</strong> {prec_meaning}</li>
            <li><strong>Recall:</strong> {rec_meaning}</li>
            <li><strong>현재 상태:</strong> {pr_note}</li>
          </ul>
          <br>
          <p><strong>실무 가이드:</strong> {tradeoff}</p>
          <br>
          <p><strong>F1 Score</strong>는 Precision과 Recall의 조화 평균으로,
          클래스 불균형 상황에서 Accuracy보다 신뢰할 수 있는 지표입니다.
          현재 F1(weighted) = {metrics.get("F1 (weighted)", 0):.4f}로,
          클래스 빈도를 감안한 실질적 성능을 나타냅니다.</p>
        </div>'''


# ── 평가 보고서 ───────────────────────────────────────────────────────────────
def generate_evaluation_report(metrics, y_test, y_pred, task, model_type,
                                output_dir, target_col, X_test, model, feature_names):
    sections = []
    is_binary = len(np.unique(y_test)) == 2

    # ── 메트릭 카드 ──────────────────────────────────────────────────────────
    cards = ''.join(
        f'<div class="metric-card"><div class="val">{v:.4f}</div><div class="lbl">{k}</div></div>'
        for k, v in metrics.items()
    )
    n_cards = len(metrics)
    grid_cls = 'grid3' if n_cards >= 3 else 'grid2'
    sections.append(f'<div class="card"><h2>📊 주요 성능 지표</h2>'
                    f'<div class="{grid_cls}">{cards}</div></div>')

    if task == 'classification':
        # ── 분류 보고서 (per-class precision/recall/f1) ─────────────────────
        cr_dict = classification_report(y_test, y_pred, output_dict=True, zero_division=0)
        cr_df = pd.DataFrame(cr_dict).T.round(4)
        cr_df.index.name = 'Class / 집계'
        cr_html = cr_df.to_html(classes='table', border=0)

        sections.append(f'''
        <div class="card">
          <h2>📋 클래스별 분류 보고서 (Precision / Recall / F1)</h2>
          {cr_html}
          <div class="info" style="margin-top:14px">
            <strong>읽는 법:</strong>
            precision = 해당 클래스로 예측한 것 중 실제 그 클래스 비율 |
            recall = 실제 그 클래스 중 올바르게 예측한 비율 |
            f1-score = precision과 recall의 조화 평균 |
            support = 실제 해당 클래스 샘플 수
          </div>
        </div>''')

        # ── 혼동 행렬 ────────────────────────────────────────────────────────
        cm = confusion_matrix(y_test, y_pred)
        classes = np.unique(y_test)
        fig, axes = plt.subplots(1, 2, figsize=(13, 5))

        # 카운트 히트맵
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=axes[0],
                    xticklabels=[f'Pred: {c}' for c in classes],
                    yticklabels=[f'Actual: {c}' for c in classes],
                    linewidths=1, linecolor='white',
                    annot_kws={'size': 13, 'weight': 'bold'})
        axes[0].set_title('Confusion Matrix (Count)', fontsize=12, fontweight='bold')

        # 정규화 히트맵 (행 합계 = 1)
        cm_norm = cm.astype(float) / cm.sum(axis=1, keepdims=True)
        sns.heatmap(cm_norm, annot=True, fmt='.2%', cmap='RdYlGn', ax=axes[1],
                    xticklabels=[f'Pred: {c}' for c in classes],
                    yticklabels=[f'Actual: {c}' for c in classes],
                    vmin=0, vmax=1, linewidths=1, linecolor='white',
                    annot_kws={'size': 12})
        axes[1].set_title('Confusion Matrix (Normalized)', fontsize=12, fontweight='bold')
        plt.tight_layout()
        sections.append(f'''
        <div class="card">
          <h2>🔲 혼동 행렬</h2>
          {img_tag(fig_to_b64(fig), '왼쪽: 실제 개수 | 오른쪽: 클래스별 비율 (대각선이 높을수록 좋음)')}
        </div>''')

        # ── ROC 커브 (이진) ──────────────────────────────────────────────────
        if is_binary:
            try:
                y_prob = model.predict_proba(X_test)[:, 1]
                fpr, tpr, thresholds = roc_curve(y_test, y_prob)
                roc_auc = auc(fpr, tpr)

                fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5))
                ax1.plot(fpr, tpr, color='#0f3460', lw=2.5,
                         label=f'ROC (AUC = {roc_auc:.4f})')
                ax1.fill_between(fpr, tpr, alpha=0.1, color='#0f3460')
                ax1.plot([0, 1], [0, 1], 'k--', lw=1, label='Random Classifier')
                ax1.set_xlabel('False Positive Rate (FPR)')
                ax1.set_ylabel('True Positive Rate (TPR = Recall)')
                ax1.set_title(f'ROC Curve (AUC={roc_auc:.4f})', fontweight='bold')
                ax1.legend(); ax1.set_xlim(0, 1); ax1.set_ylim(0, 1.02)

                # Precision-Recall 커브
                from sklearn.metrics import precision_recall_curve, average_precision_score
                prec_curve, rec_curve, _ = precision_recall_curve(y_test, y_prob)
                ap = average_precision_score(y_test, y_prob)
                ax2.plot(rec_curve, prec_curve, color='#e94560', lw=2.5,
                         label=f'PR Curve (AP={ap:.4f})')
                ax2.fill_between(rec_curve, prec_curve, alpha=0.1, color='#e94560')
                ax2.set_xlabel('Recall')
                ax2.set_ylabel('Precision')
                ax2.set_title(f'Precision-Recall Curve (AP={ap:.4f})', fontweight='bold')
                ax2.legend(); ax2.set_xlim(0, 1); ax2.set_ylim(0, 1.02)
                plt.tight_layout()
                sections.append(f'''
                <div class="card">
                  <h2>📈 ROC & Precision-Recall 커브</h2>
                  {img_tag(fig_to_b64(fig),
                           'AUC가 1에 가까울수록, AP가 높을수록 우수한 모델. 클래스 불균형 시 PR 커브가 더 신뢰성 있음')}
                </div>''')
            except Exception:
                pass

    else:  # regression
        # ── 예측 vs 실제 & 잔차 ──────────────────────────────────────────────
        y_test_arr = np.array(y_test)
        y_pred_arr = np.array(y_pred)
        residuals = y_test_arr - y_pred_arr

        fig, axes = plt.subplots(1, 3, figsize=(18, 5))
        # scatter
        axes[0].scatter(y_test_arr, y_pred_arr, alpha=0.4, s=18, color='#0f3460')
        mn, mx = min(y_test_arr.min(), y_pred_arr.min()), max(y_test_arr.max(), y_pred_arr.max())
        axes[0].plot([mn, mx], [mn, mx], 'r--', lw=1.5)
        axes[0].set_xlabel('Actual'); axes[0].set_ylabel('Predicted')
        axes[0].set_title('Predicted vs Actual', fontweight='bold')
        # residuals dist
        axes[1].hist(residuals, bins=40, color='#e94560', alpha=0.8, edgecolor='white')
        axes[1].axvline(0, color='black', linestyle='--', lw=1.5)
        axes[1].axvline(residuals.mean(), color='#ff9800', linestyle='-', lw=1.5,
                        label=f'Residual Mean: {residuals.mean():.4g}')
        axes[1].set_title('Residual Distribution', fontweight='bold'); axes[1].legend()
        # residuals vs predicted
        axes[2].scatter(y_pred_arr, residuals, alpha=0.4, s=18, color='#16213e')
        axes[2].axhline(0, color='red', linestyle='--', lw=1.5)
        axes[2].set_xlabel('Predicted'); axes[2].set_ylabel('Residual')
        axes[2].set_title('Residual vs Predicted', fontweight='bold')
        plt.tight_layout()
        sections.append(f'''
        <div class="card">
          <h2>📉 예측 성능 시각화</h2>
          {img_tag(fig_to_b64(fig),
                   '좌: 대각선에 가까울수록 좋음 | 중: 잔차가 0 중심으로 대칭적이면 좋음 | 우: 패턴 없이 랜덤하면 좋음')}
        </div>''')

    # ── 특성 중요도 ──────────────────────────────────────────────────────────
    if hasattr(model, 'feature_importances_'):
        imp = model.feature_importances_
        n = min(20, len(feature_names))
        idx = np.argsort(imp)[-n:]
        top_names = [feature_names[i] for i in idx]
        top_imp = imp[idx]

        fig, ax = plt.subplots(figsize=(10, max(5, n*0.38)))
        colors = plt.cm.viridis(np.linspace(0.2, 0.9, n))
        bars = ax.barh(range(n), top_imp, color=colors)
        ax.set_yticks(range(n))
        ax.set_yticklabels(top_names, fontsize=9)
        ax.set_xlabel('Feature Importance (Impurity-based)')
        ax.set_title(f'Top {n} Feature Importances', fontweight='bold')
        for bar, val in zip(bars, top_imp):
            ax.text(val + max(top_imp)*0.01, bar.get_y() + bar.get_height()/2,
                    f'{val:.4f}', va='center', fontsize=8)
        plt.tight_layout()
        sections.append(f'''
        <div class="card">
          <h2>🏆 Feature 중요도</h2>
          {img_tag(fig_to_b64(fig), '값이 클수록 예측에 영향력이 큰 Feature')}
        </div>''')

    # ── 전문가 해석 ──────────────────────────────────────────────────────────
    interp = build_expert_interpretation(metrics, y_test, y_pred, task, target_col)
    sections.append(f'<div class="card"><h2>💡 전문가 해석 & 실무 가이드</h2>{interp}</div>')

    # ── HTML 조립 ─────────────────────────────────────────────────────────────
    html = HTML_HEADER.replace('{title}', 'Evaluation Report')
    html += f'''
    <header>
      <h1>🤖 모델 평가 보고서</h1>
      <div class="meta">
        <span class="badge">모델: {model_type}</span>
        <span class="badge">타겟: {target_col}</span>
        <span class="badge">{'분류' if task == 'classification' else '회귀'}</span>
        <span class="badge">테스트 샘플: {len(y_test):,}개</span>
      </div>
    </header>
    <main>{"".join(sections)}</main></body></html>'''

    path = os.path.join(output_dir, 'evaluation_report.html')
    with open(path, 'w', encoding='utf-8') as f:
        f.write(html)
    print(f"  - Evaluation report: {path}")
    return path


# ── Streamlit 앱 ──────────────────────────────────────────────────────────────
def generate_streamlit_app(df, target_col, task, model_type, label_encoders, output_dir):
    feat_cols = [c for c in df.columns if c != target_col]
    num_cols = df.select_dtypes(include=np.number).columns.tolist()

    widgets = []
    for col in feat_cols:
        if col in label_encoders:
            opts = repr(sorted(df[col].dropna().unique().tolist()))
            widgets.append(
                f'{col}_v = st.sidebar.selectbox("{col}", {opts})\n'
                f'inp["{col}"] = {col}_v'
            )
        elif col in num_cols:
            mn = float(df[col].min()); mx = float(df[col].max()); mv = float(df[col].mean())
            widgets.append(
                f'inp["{col}"] = st.sidebar.slider("{col}", {mn!r}, {mx!r}, {mv!r})'
            )
        else:
            opts = repr(sorted(df[col].dropna().astype(str).unique().tolist()))
            widgets.append(f'inp["{col}"] = st.sidebar.selectbox("{col}", {opts})')

    widgets_code = '\n'.join(widgets)

    docstring = f'"""Streamlit Inference App — {model_type} | {task} | target: {target_col}\nRun: streamlit run app.py\n"""'

    code = f'''{docstring}
import streamlit as st
import pandas as pd
import numpy as np
import pickle, json, os
from sklearn.preprocessing import LabelEncoder

st.set_page_config(page_title="ML 추론 앱", page_icon="🤖", layout="wide")

@st.cache_resource
def load_artifacts():
    base = os.path.dirname(__file__)
    with open(os.path.join(base, "model.pkl"), "rb") as f:
        model = pickle.load(f)
    with open(os.path.join(base, "metadata.json")) as f:
        meta = json.load(f)
    return model, meta

model, meta = load_artifacts()
label_encoders = {{}}

st.title("🤖 ML 추론 앱")
st.markdown(f"**모델:** `{model_type}` &nbsp;|&nbsp; **타겟:** `{target_col}` &nbsp;|&nbsp; **태스크:** {task}")
st.divider()

st.sidebar.header("📥 입력값")
inp = {{}}
{widgets_code}

col1, col2 = st.columns([1, 1])
with col1:
    st.subheader("입력 데이터")
    st.dataframe(pd.DataFrame([inp]), use_container_width=True)
with col2:
    st.subheader("🎯 예측")
    try:
        X = pd.DataFrame([inp])[meta["features"]]
        pred = model.predict(X)[0]
        if meta["task_type"] == "classification":
            st.metric("예측 클래스", str(int(pred)))
            try:
                proba = model.predict_proba(X)[0]
                classes = [str(c) for c in model.classes_]
                st.bar_chart(pd.DataFrame({{"클래스": classes, "확률": proba}}).set_index("클래스"))
            except Exception:
                pass
        else:
            st.metric("예측값", f"{{pred:,.4f}}")
    except Exception as e:
        st.error(f"오류: {{e}}")

st.divider()
st.subheader("📂 배치 예측 (X_test CSV 업로드)")
st.caption("타겟 컬럼이 없는 피처 파일을 업로드하세요. 타겟 컬럼이 있어도 자동으로 제외하고 예측합니다.")

tab1, tab2 = st.tabs(["🔮 배치 예측", "📊 성능 평가 (y_test 업로드)"])

with tab1:
    up_x = st.file_uploader("X_test CSV 업로드", type=["csv"], key="x_upload")
    if up_x:
        batch = pd.read_csv(up_x)
        # 타겟 컬럼이 있으면 자동 제외
        feat_cols = meta["features"]
        missing_cols = [c for c in feat_cols if c not in batch.columns]
        if missing_cols:
            st.error(f"필요한 피처 컬럼이 없습니다: {{missing_cols}}")
        else:
            try:
                X_batch = batch[feat_cols]
                preds = model.predict(X_batch)
                res = batch.copy()
                res["prediction"] = preds
                if meta["task_type"] == "classification":
                    try:
                        proba = model.predict_proba(X_batch)
                        for i, cls in enumerate(model.classes_):
                            res[f"proba_{{int(cls) if float(cls)==int(float(cls)) else cls}}"] = proba[:, i]
                    except Exception:
                        pass
                st.success(f"✅ {{len(res):,}}건 예측 완료")
                st.dataframe(res, use_container_width=True)
                csv_bytes = res.to_csv(index=False).encode("utf-8")
                st.download_button("💾 결과 다운로드", csv_bytes, "predictions.csv", "text/csv")
            except Exception as e:
                st.error(f"예측 오류: {{e}}")

with tab2:
    st.markdown("X_test 예측 결과와 실제 정답(y_test)을 비교해 모델 성능을 평가합니다.")
    col_a, col_b = st.columns(2)
    with col_a:
        up_x2 = st.file_uploader("X_test CSV", type=["csv"], key="x2_upload")
    with col_b:
        up_y = st.file_uploader("y_test CSV (타겟 컬럼만)", type=["csv"], key="y_upload")

    if up_x2 and up_y:
        try:
            X_eval = pd.read_csv(up_x2)
            y_eval = pd.read_csv(up_y)

            feat_cols = meta["features"]
            missing_cols = [c for c in feat_cols if c not in X_eval.columns]
            if missing_cols:
                st.error(f"X_test에 필요한 컬럼 없음: {{missing_cols}}")
            elif len(X_eval) != len(y_eval):
                st.error(f"행 수 불일치: X_test={{len(X_eval)}}행, y_test={{len(y_eval)}}행")
            else:
                preds = model.predict(X_eval[feat_cols])
                y_true = y_eval.iloc[:, 0].values

                if meta["task_type"] == "classification":
                    from sklearn.metrics import (classification_report, confusion_matrix,
                                                 accuracy_score, f1_score, roc_auc_score)
                    acc = accuracy_score(y_true, preds)
                    f1  = f1_score(y_true, preds, average="macro", zero_division=0)

                    st.success(f"✅ 평가 완료 — Accuracy: **{{acc:.4f}}** | F1 (macro): **{{f1:.4f}}**")

                    # Metrics 카드
                    m1, m2, m3 = st.columns(3)
                    m1.metric("Accuracy",   f"{{acc:.4f}}")
                    m2.metric("F1 (macro)", f"{{f1:.4f}}")
                    try:
                        auc = roc_auc_score(y_true, model.predict_proba(X_eval[feat_cols])[:, 1])
                        m3.metric("ROC-AUC", f"{{auc:.4f}}")
                    except Exception:
                        m3.metric("ROC-AUC", "N/A")

                    # Classification report 테이블
                    st.subheader("Classification Report")
                    report = classification_report(y_true, preds, output_dict=True, zero_division=0)
                    report_df = pd.DataFrame(report).T.round(4)
                    st.dataframe(report_df, use_container_width=True)

                    # Confusion matrix
                    st.subheader("Confusion Matrix")
                    cm = confusion_matrix(y_true, preds)
                    cm_df = pd.DataFrame(cm,
                        index=[f"실제 {{c}}" for c in sorted(set(y_true))],
                        columns=[f"예측 {{c}}" for c in sorted(set(y_true))])
                    st.dataframe(cm_df, use_container_width=True)

                else:
                    from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
                    mae  = mean_absolute_error(y_true, preds)
                    rmse = mean_squared_error(y_true, preds) ** 0.5
                    r2   = r2_score(y_true, preds)

                    st.success(f"✅ 평가 완료")
                    m1, m2, m3 = st.columns(3)
                    m1.metric("MAE",  f"{{mae:,.4f}}")
                    m2.metric("RMSE", f"{{rmse:,.4f}}")
                    m3.metric("R²",   f"{{r2:.4f}}")

                    result_df = pd.DataFrame({{"실제값": y_true, "예측값": preds, "잔차": y_true - preds}})
                    st.subheader("예측 vs 실제")
                    st.dataframe(result_df, use_container_width=True)

                # 결과 다운로드
                result_full = X_eval.copy()
                result_full["y_true"] = y_true
                result_full["y_pred"] = preds
                st.download_button("💾 평가 결과 다운로드",
                    result_full.to_csv(index=False).encode("utf-8"),
                    "eval_result.csv", "text/csv")

        except Exception as e:
            st.error(f"평가 오류: {{e}}")
            import traceback; st.code(traceback.format_exc())
'''
    path = os.path.join(output_dir, 'app.py')
    with open(path, 'w', encoding='utf-8') as f:
        f.write(code)
    print(f"  - Streamlit app: {path}")
    return path


def generate_requirements(output_dir):
    content = "pandas>=1.5.0\nnumpy>=1.23.0\nscikit-learn>=1.2.0\nmatplotlib>=3.6.0\nseaborn>=0.12.0\nstreamlit>=1.28.0\n"
    path = os.path.join(output_dir, 'requirements.txt')
    with open(path, 'w') as f:
        f.write(content)
    print(f"  - requirements.txt: {path}")


# ── main ─────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description='CSV ML Pipeline')
    parser.add_argument('--csv', required=True)
    parser.add_argument('--target', required=True)
    parser.add_argument('--task', required=True, choices=['regression', 'classification'])
    parser.add_argument('--model', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--class-weight', default='',
                        help="분류 모델의 class_weight 설정 (예: balanced). "
                             "타겟 불균형 비율 5:1 초과 시 권장.")
    parser.add_argument('--mode', choices=['eda', 'model', 'full'], default='full',
                        help='eda: EDA만 | model: 모델링만 | full: 전체(기본)')
    parser.add_argument('--fill-strategy', default='drop',
                        choices=['drop', 'median', 'mean'],
                        help='결측치 처리: drop(제거) | median | mean')
    args = parser.parse_args()

    os.makedirs(args.output, exist_ok=True)

    print(f"\n{'='*55}\n  CSV ML Pipeline\n  파일: {os.path.basename(args.csv)}"
          f"\n  타겟: {args.target}  |  태스크: {args.task}  |  모델: {args.model}\n{'='*55}\n")

    print("📥 데이터 로딩...")
    df = load_csv(args.csv)
    print(f"   → {df.shape[0]:,} rows × {df.shape[1]} cols")

    # ── EDA 단계 ──────────────────────────────────────────────────────────
    if args.mode in ('eda', 'full'):
        print("📊 EDA 보고서 생성...")
        generate_eda_report(df, args.target, args.output)
        if args.mode == 'eda':
            print(f"\n✅ EDA 완료: {os.path.join(args.output, 'eda_report.html')}")
            return

    # ── 모델링 단계 ────────────────────────────────────────────────────────
    print("⚙️  전처리...")
    X, y, label_encoders = preprocess_data(df, args.target)
    print(f"   → features: {X.shape[1]}, samples: {X.shape[0]:,}")

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    print(f"🤖 모델 학습 ({args.model})...")
    class_weight = getattr(args, 'class_weight', '') or None
    model = train_model(X_train, y_train, args.model, args.task, class_weight=class_weight)

    print("📈 평가...")
    metrics, y_pred = evaluate_model(model, X_test, y_test, args.task)
    for k, v in metrics.items():
        print(f"   {k}: {v:.4f}")

    save_model(model, args.output)
    save_metadata(model, X, metrics, args.output, args.target, args.task, args.model)

    predictions_path = os.path.join(args.output, 'predictions.json')
    with open(predictions_path, 'w') as f:
        json.dump({'actual': y_test.tolist(), 'predicted': y_pred.tolist()}, f)

    print("📝 평가 보고서 생성...")
    generate_evaluation_report(metrics, y_test, y_pred, args.task, args.model,
                                args.output, args.target, X_test, model,
                                list(X.columns))

    print("🚀 Streamlit 앱 생성...")
    generate_streamlit_app(df, args.target, args.task, args.model,
                           label_encoders, args.output)
    generate_requirements(args.output)

    print(f"""
{'='*55}
  ✅ 파이프라인 완료!

  출력 폴더: {args.output}
    ├── eda_report.html        EDA 보고서
    ├── model.pkl              학습된 모델
    ├── evaluation_report.html 성능 평가 보고서
    ├── app.py                 Streamlit 추론 웹앱
    └── requirements.txt

  [Streamlit 앱 실행]
    cd {args.output}
    pip install -r requirements.txt
    streamlit run app.py

  앱: http://localhost:8501
{'='*55}
""")


if __name__ == '__main__':
    main()
